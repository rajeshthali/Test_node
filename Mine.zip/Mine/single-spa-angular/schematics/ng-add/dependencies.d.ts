import { NodeDependency } from '@schematics/angular/utility/dependencies';
export declare function getSingleSpaDependency(): NodeDependency;
export declare function getSingleSpaAngularDependency(): NodeDependency;
/**
 * We have to install `@angular-builders/custom-webpack` version compatible with the current
 * version of Angular. If Angular is 8 then `custom-webpack@8.4.1` has to be installed.
 */
export declare function getAngularBuildersCustomWebpackDependency(): NodeDependency;
