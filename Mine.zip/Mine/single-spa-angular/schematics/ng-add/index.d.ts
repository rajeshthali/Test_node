import { Rule, SchematicContext, Tree } from '@angular-devkit/schematics';
import { Schema as NgAddOptions } from './schema';
export default function (options: NgAddOptions): Rule;
export declare function addDependencies(): Rule;
export declare function createMainEntry(options: NgAddOptions): Rule;
export declare function updateConfiguration(options: NgAddOptions): (host: Tree, context: SchematicContext) => import("@angular-devkit/schematics/src/tree/interface").Tree;
export declare function addNPMScripts(options: NgAddOptions): Rule;
