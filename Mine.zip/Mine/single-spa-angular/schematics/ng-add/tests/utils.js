"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTestRunner = exports.createWorkspace = void 0;
const tslib_1 = require("tslib");
const path_1 = require("path");
const testing_1 = require("@angular-devkit/schematics/testing");
const collectionPath = path_1.join(__dirname, '../../schematics.json');
function createWorkspace(testRunner, appTree, workspaceOptions, appOptions) {
    return tslib_1.__awaiter(this, void 0, void 0, function* () {
        appTree = yield testRunner
            .runExternalSchematicAsync('@schematics/angular', 'workspace', workspaceOptions)
            .toPromise();
        appTree = yield testRunner
            .runExternalSchematicAsync('@schematics/angular', 'application', appOptions, appTree)
            .toPromise();
        return appTree;
    });
}
exports.createWorkspace = createWorkspace;
function createTestRunner() {
    return new testing_1.SchematicTestRunner('single-spa-angular', collectionPath);
}
exports.createTestRunner = createTestRunner;
//# sourceMappingURL=utils.js.map