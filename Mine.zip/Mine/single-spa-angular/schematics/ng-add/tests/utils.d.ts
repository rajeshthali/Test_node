import { SchematicTestRunner, UnitTestTree } from '@angular-devkit/schematics/testing';
export declare function createWorkspace<WorkspaceOptions, AppOptions>(testRunner: SchematicTestRunner, appTree: UnitTestTree, workspaceOptions: WorkspaceOptions, appOptions: AppOptions): Promise<UnitTestTree>;
export declare function createTestRunner(): SchematicTestRunner;
