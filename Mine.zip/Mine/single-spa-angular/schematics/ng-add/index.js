"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addNPMScripts = exports.updateConfiguration = exports.createMainEntry = exports.addDependencies = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const config_1 = require("@schematics/angular/utility/config");
const dependencies_1 = require("@schematics/angular/utility/dependencies");
const path_1 = require("path");
const add_scripts_1 = require("./add-scripts");
const dependencies_2 = require("./dependencies");
const json_utils_1 = require("@schematics/angular/utility/json-utils");
const core_1 = require("@angular-devkit/core");
function default_1(options) {
    return schematics_1.chain([
        addDependencies(),
        createMainEntry(options),
        updateConfiguration(options),
        addNPMScripts(options),
    ]);
}
exports.default = default_1;
function addDependencies() {
    const dependencies = [
        dependencies_2.getSingleSpaDependency(),
        dependencies_2.getSingleSpaAngularDependency(),
        dependencies_2.getAngularBuildersCustomWebpackDependency(),
    ];
    return (tree, context) => {
        for (const dependency of dependencies) {
            dependencies_1.addPackageJsonDependency(tree, dependency);
            context.logger.info(`Added '${dependency.name}' as a dependency`);
        }
    };
}
exports.addDependencies = addDependencies;
function createMainEntry(options) {
    return (host, context) => {
        const project = getClientProject(host, options);
        const path = path_1.normalize(project.workspace.root);
        const templateSource = schematics_1.apply(schematics_1.url('./_files'), [
            schematics_1.applyTemplates({
                atLeastAngular8: atLeastAngular8(),
                prefix: project.workspace.prefix,
                routing: options.routing,
                usingBrowserAnimationsModule: options.usingBrowserAnimationsModule,
            }),
            schematics_1.move(path),
        ]);
        const rule = schematics_1.mergeWith(templateSource, schematics_1.MergeStrategy.Overwrite);
        context.logger.info(`Generated 'main.single-spa.ts`);
        context.logger.info(`Generated 'single-spa-props.ts`);
        context.logger.info(`Generated asset-url.ts`);
        context.logger.info(`Generated extra-webpack.config.js`);
        return rule(host, context);
    };
}
exports.createMainEntry = createMainEntry;
function updateConfiguration(options) {
    return (host, context) => {
        const workspace = config_1.getWorkspace(host);
        const project = getClientProject(host, options);
        const clientProject = workspace.projects[project.name];
        if (!clientProject.architect) {
            throw new Error('Client project architect not found.');
        }
        const workspacePath = config_1.getWorkspacePath(host);
        if (atLeastAngular8()) {
            updateProjectNewAngular(context, clientProject, project.name);
            updateTSConfig(host, clientProject);
        }
        else {
            updateProjectOldAngular(context, clientProject, project);
        }
        host.overwrite(workspacePath, JSON.stringify(workspace, null, 2));
        context.logger.info(`Updated angular.json configuration`);
        // @ts-ignore
        context.logger.info(clientProject.architect.build.builder);
        return host;
    };
}
exports.updateConfiguration = updateConfiguration;
function updateProjectOldAngular(context, clientProject, project) {
    context.logger.info('Using single-spa-angular builder for Angular versions before 8');
    // Copy configuration from build architect
    clientProject.architect['single-spa'] = clientProject.architect.build;
    clientProject.architect['single-spa'].builder = 'single-spa-angular:build';
    clientProject.architect['single-spa'].options.main = `${project.workspace.sourceRoot}/main.single-spa.ts`;
    // Copy configuration from the serve architect
    clientProject.architect['single-spa-serve'] = clientProject.architect.serve;
    clientProject.architect['single-spa-serve'].builder = 'single-spa-angular:dev-server';
    clientProject.architect['single-spa-serve'].options.browserTarget = `${project.name}:single-spa`;
}
function updateProjectNewAngular(context, clientProject, projectName) {
    context.logger.info('Using @angular-devkit/custom-webpack builder.');
    const buildTarget = clientProject.architect.build;
    const browserBuilder = '@angular-builders/custom-webpack:browser';
    buildTarget.builder = browserBuilder;
    buildTarget.options.main = path_1.join(clientProject.root, 'src/main.single-spa.ts');
    buildTarget.options.customWebpackConfig = {
        path: path_1.join(clientProject.root, 'extra-webpack.config.js'),
        libraryName: projectName,
        libraryTarget: 'umd',
    };
    updateConfigurationsAndDisableOutputHashing(clientProject);
    const devServerBuilder = '@angular-builders/custom-webpack:dev-server';
    clientProject.architect.serve.builder = devServerBuilder;
}
function updateTSConfig(host, clientProject) {
    const tsConfigFileName = clientProject.architect.build.options.tsConfig;
    const buffer = host.read(tsConfigFileName);
    if (!buffer) {
        return;
    }
    const tsCfgAst = core_1.parseJsonAst(buffer.toString(), core_1.JsonParseMode.Loose);
    if (tsCfgAst.kind !== 'object') {
        return;
    }
    const files = json_utils_1.findPropertyInAstObject(tsCfgAst, 'files');
    if (files && files.kind !== 'array') {
        return;
    }
    // The "files" property will only contain path to `main.single-spa.ts` file,
    // because we remove `polyfills` from Webpack `entry` property.
    const recorder = host.beginUpdate(tsConfigFileName);
    if (files) {
        json_utils_1.removePropertyInAstObject(recorder, tsCfgAst, 'files');
    }
    json_utils_1.insertPropertyInAstObjectInOrder(recorder, tsCfgAst, 'files', ['src/main.single-spa.ts'], 2);
    host.commitUpdate(recorder);
}
function addNPMScripts(options) {
    return (host) => {
        const pkgPath = '/package.json';
        const buffer = host.read(pkgPath);
        if (buffer === null) {
            throw new schematics_1.SchematicsException('Could not find package.json');
        }
        add_scripts_1.addScripts(host, pkgPath, JSON.parse(buffer.toString()), options.project);
    };
}
exports.addNPMScripts = addNPMScripts;
function getClientProject(host, options) {
    const workspace = config_1.getWorkspace(host);
    let project = options.project;
    if (!options.project) {
        project = Object.keys(workspace.projects)[0];
    }
    const clientProject = workspace.projects[project];
    if (!clientProject) {
        throw new schematics_1.SchematicsException(`Client app ${options.project} not found.`);
    }
    return { name: project, workspace: clientProject };
}
function atLeastAngular8() {
    const { VERSION } = require('@angular/core');
    return Number(VERSION.major) >= 8;
}
function updateConfigurationsAndDisableOutputHashing(clientProject) {
    const configurations = clientProject.architect.build.configurations;
    // If the user doesn't have any `configurations` then just skip this step.
    if (typeof configurations !== 'object') {
        return;
    }
    for (const configuration of Object.values(configurations)) {
        configuration.outputHashing = 'none';
    }
}
//# sourceMappingURL=index.js.map