import { Tree } from '@angular-devkit/schematics';
/**
 * The user can have multiple applications inside the same workspace.
 * E.g. consider following commands:
 *
 * - `yarn ng new --createApplication false workspace`
 * - `yarn ng generate application first-cool-app`
 * - `yarn ng generate application second-cool-app`
 * - `yarn ng add single-spa-angular --project first-cool-app`
 * - `yarn ng add single-spa-angular --project second-cool-app`
 *
 * In that case our schematics should respect passed `--project` argument.
 * Basically it will create different scripts for different applications, thus the
 * user will be able to run them in parallel. Created scripts will be:
 *
 * - build:single-spa:first-cool-app
 * - serve:single-spa:first-cool-app
 *
 * - build:single-spa:second-cool-app
 * - serve:single-spa:second-cool-app
 */
export declare function addScripts(tree: Tree, pkgPath: string, pkg: any, project: string | undefined): void;
