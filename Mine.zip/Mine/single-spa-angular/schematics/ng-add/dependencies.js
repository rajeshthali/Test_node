"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAngularBuildersCustomWebpackDependency = exports.getSingleSpaAngularDependency = exports.getSingleSpaDependency = void 0;
const dependencies_1 = require("@schematics/angular/utility/dependencies");
const { version, peerDependencies, dependencies } = require('../../package.json');
function getSingleSpaDependency() {
    const singleSpaVersion = (peerDependencies === null || peerDependencies === void 0 ? void 0 : peerDependencies['single-spa']) || (dependencies === null || dependencies === void 0 ? void 0 : dependencies['single-spa']) || 'latest';
    return {
        name: 'single-spa',
        version: singleSpaVersion,
        overwrite: true,
        type: dependencies_1.NodeDependencyType.Default,
    };
}
exports.getSingleSpaDependency = getSingleSpaDependency;
function getSingleSpaAngularDependency() {
    return {
        name: 'single-spa-angular',
        version,
        overwrite: false,
        type: dependencies_1.NodeDependencyType.Default,
    };
}
exports.getSingleSpaAngularDependency = getSingleSpaAngularDependency;
/**
 * We have to install `@angular-builders/custom-webpack` version compatible with the current
 * version of Angular. If Angular is 8 then `custom-webpack@8.4.1` has to be installed.
 */
function getAngularBuildersCustomWebpackDependency() {
    const { VERSION } = require('@angular/core');
    return {
        name: '@angular-builders/custom-webpack',
        version: `^${VERSION.major}`,
        overwrite: false,
        type: dependencies_1.NodeDependencyType.Dev,
    };
}
exports.getAngularBuildersCustomWebpackDependency = getAngularBuildersCustomWebpackDependency;
//# sourceMappingURL=dependencies.js.map