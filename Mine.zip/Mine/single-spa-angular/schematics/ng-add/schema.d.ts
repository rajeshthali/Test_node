export interface Schema {
  project?: string;
  routing?: boolean;
  usingBrowserAnimationsModule?: boolean;
}
