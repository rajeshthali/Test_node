/**
 * The public api for consumers of single-spa-angular
 */
export * from './src/public_api';
