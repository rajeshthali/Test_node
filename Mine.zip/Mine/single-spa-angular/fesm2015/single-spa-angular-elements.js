import { __awaiter } from 'tslib';
import { getContainerElementAndSetTemplate } from 'single-spa-angular/internals';

const defaultOptions = {
    element: null,
    template: null,
    ngModuleRef: null,
    bootstrapFunction: null,
    domElementGetter: undefined,
};
function bootstrap(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        if (options.ngModuleRef !== null) {
            return;
        }
        // We call `bootstrapFunction()` inside the bootstrap lifecycle hook
        // because Angular modules that expose custom elements should be
        // bootstrapped only once.
        options.ngModuleRef = yield options.bootstrapFunction(props);
    });
}
function mount(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        const containerElement = getContainerElementAndSetTemplate(options, props);
        // `options.template` which can be `<app-element />` is not a valid selector
        // for `document.querySelector`, thus we retrieve this custom element
        // via this property.
        options.element = containerElement.firstElementChild;
    });
}
function unmount(options) {
    return Promise.resolve().then(() => {
        // Removing custom element from DOM is enough since it will trigger
        // `disconnectedCallback()` and Angular will dispose all resources.
        options.element.parentElement.removeChild(options.element);
        options.element = null;
    });
}
function singleSpaAngularElements(userOptions) {
    const options = Object.assign(Object.assign({}, defaultOptions), userOptions);
    return {
        bootstrap: bootstrap.bind(null, options),
        mount: mount.bind(null, options),
        unmount: unmount.bind(null, options),
    };
}

/**
 * Generated bundle index. Do not edit.
 */

export { singleSpaAngularElements };
//# sourceMappingURL=single-spa-angular-elements.js.map
