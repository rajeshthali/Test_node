import { StaticProvider } from '@angular/core';
import { ɵBrowserPlatformLocation, LocationChangeEvent } from '@angular/common';
import * as ɵngcc0 from '@angular/core';
declare type OnPopStateListener = (event: LocationChangeEvent) => void;
export declare class SingleSpaPlatformLocation extends ɵBrowserPlatformLocation {
    private skipNextPopState;
    private zoneToOnPopStateListenersMap;
    private source;
    destroyApplication(zoneIdentifier: string): void;
    pushState(state: any, title: string, url: string): void;
    replaceState(state: any, title: string, url: string): void;
    onPopState(fn: OnPopStateListener): void;
    private storeOnPopStateListener;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<SingleSpaPlatformLocation, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<SingleSpaPlatformLocation>;
}
/**
 * The `PlatformLocation` class is an "injectee" of the `PathLocationStrategy`,
 * which creates `Subject` internally for listening on `popstate` events. We want
 * to provide this class in the most top injector that's used during bootstrapping.
 */
export declare function getSingleSpaExtraProviders(): StaticProvider[];
export {};

//# sourceMappingURL=extra-providers.d.ts.map