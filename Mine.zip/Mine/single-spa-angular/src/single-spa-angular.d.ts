import { LifeCycles } from 'single-spa';
import { SingleSpaAngularOptions } from './types';
export declare function singleSpaAngular<T>(userOptions: SingleSpaAngularOptions<T>): LifeCycles<T>;
