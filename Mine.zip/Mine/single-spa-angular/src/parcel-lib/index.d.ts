import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './parcel.component';
export declare class ParcelModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<ParcelModule, [typeof ɵngcc1.ParcelComponent], never, [typeof ɵngcc1.ParcelComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<ParcelModule>;
}

//# sourceMappingURL=index.d.ts.map