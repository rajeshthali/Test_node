import { OnInit, OnDestroy, OnChanges, ElementRef } from '@angular/core';
import { Parcel, ParcelConfig, AppProps } from 'single-spa';
import * as ɵngcc0 from '@angular/core';
export declare class ParcelComponent implements OnInit, OnDestroy, OnChanges {
    private host;
    config: ParcelConfig;
    mountParcel: AppProps['mountParcel'];
    onParcelMount: (() => void) | null;
    wrapWith: string;
    customProps: object;
    appendTo: Node | null;
    handleError: (error: Error) => void;
    createdDomElement: HTMLElement | null;
    hasError: boolean;
    unmounted: boolean;
    nextThingToDo: Promise<any>;
    parcel: Parcel;
    constructor(host: ElementRef<HTMLElement>);
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    addThingToDo(action: string, thing: Function): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ParcelComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<ParcelComponent, "parcel", never, { "onParcelMount": "onParcelMount"; "wrapWith": "wrapWith"; "customProps": "customProps"; "appendTo": "appendTo"; "handleError": "handleError"; "config": "config"; "mountParcel": "mountParcel"; }, {}, never, never>;
}

//# sourceMappingURL=parcel.component.d.ts.map