export { singleSpaAngular } from './single-spa-angular';
export { getSingleSpaExtraProviders } from './extra-providers';
export { ParcelModule } from './parcel-lib/index';
export { ParcelComponent } from './parcel-lib/parcel.component';
