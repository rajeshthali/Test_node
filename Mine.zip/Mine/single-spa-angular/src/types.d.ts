import { NgModuleRef, Type, NgZone } from '@angular/core';
import { AppProps } from 'single-spa';
import { BaseSingleSpaAngularOptions } from 'single-spa-angular/internals';
export interface SingleSpaAngularOptions<T = {}> extends BaseSingleSpaAngularOptions {
    NgZone: typeof NgZone | 'noop';
    updateFunction?(props: AppProps): Promise<any>;
    Router?: Type<any>;
    NavigationStart?: Type<any>;
    AnimationEngine?: Type<any>;
    bootstrapFunction(props: AppProps & T): Promise<NgModuleRef<any>>;
}
export interface BootstrappedSingleSpaAngularOptions extends SingleSpaAngularOptions {
    bootstrappedModule: NgModuleRef<any>;
    bootstrappedNgZone?: NgZone;
    routingEventListener?: () => void;
    zoneIdentifier?: string;
}
