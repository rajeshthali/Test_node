/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { SingleSpaPlatformLocation as ɵa } from './src/extra-providers';

//# sourceMappingURL=single-spa-angular.d.ts.map