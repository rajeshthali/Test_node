import { LifeCycles } from 'single-spa';
import { BaseSingleSpaAngularOptions } from 'single-spa-angular/internals';
export declare function singleSpaAngularElements(userOptions: BaseSingleSpaAngularOptions): LifeCycles;
