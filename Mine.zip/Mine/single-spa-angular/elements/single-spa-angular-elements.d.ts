/**
 * Generated bundle index. Do not edit.
 */
export * from './index';

//# sourceMappingURL=single-spa-angular-elements.d.ts.map