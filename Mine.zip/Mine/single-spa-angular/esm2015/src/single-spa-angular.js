import { __awaiter } from "tslib";
import { getContainerElementAndSetTemplate, removeApplicationFromDOMIfIvyEnabled, } from 'single-spa-angular/internals';
import { SingleSpaPlatformLocation } from './extra-providers';
const defaultOptions = {
    // Required options that will be set by the library consumer.
    NgZone: null,
    bootstrapFunction: null,
    template: null,
    // Optional options
    Router: undefined,
    domElementGetter: undefined,
    AnimationEngine: undefined,
    updateFunction: () => Promise.resolve(),
};
export function singleSpaAngular(userOptions) {
    if (typeof userOptions !== 'object') {
        throw Error('single-spa-angular requires a configuration object');
    }
    const options = Object.assign(Object.assign({}, defaultOptions), userOptions);
    if (typeof options.bootstrapFunction !== 'function') {
        throw Error('single-spa-angular must be passed an options.bootstrapFunction');
    }
    if (typeof options.template !== 'string') {
        throw Error('single-spa-angular must be passed options.template string');
    }
    if (!options.NgZone) {
        throw Error(`single-spa-angular must be passed the NgZone option`);
    }
    if (options.Router && !options.NavigationStart) {
        // We call `console.warn` except of throwing `new Error()` since this will not
        // be a breaking change.
        console.warn(`single-spa-angular must be passed the NavigationStart option`);
    }
    return {
        bootstrap: bootstrap.bind(null, options),
        mount: mount.bind(null, options),
        unmount: unmount.bind(null, options),
        update: options.updateFunction,
    };
}
function bootstrap(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        // Angular provides an opportunity to develop `zone-less` application, where developers
        // have to trigger change detection manually.
        // See https://angular.io/guide/zone#noopzone
        if (options.NgZone === 'noop') {
            return;
        }
        // In order for multiple Angular apps to work concurrently on a page, they each need a unique identifier.
        options.zoneIdentifier = `single-spa-angular:${props.name || props.appName}`;
        // This is a hack, since NgZone doesn't allow you to configure the property that identifies your zone.
        // See https://github.com/PlaceMe-SAS/single-spa-angular-cli/issues/33,
        // https://github.com/single-spa/single-spa-angular/issues/47,
        // https://github.com/angular/angular/blob/a14dc2d7a4821a19f20a9547053a5734798f541e/packages/core/src/zone/ng_zone.ts#L144,
        // and https://github.com/angular/angular/blob/a14dc2d7a4821a19f20a9547053a5734798f541e/packages/core/src/zone/ng_zone.ts#L257
        options.NgZone.isInAngularZone = () => {
            // @ts-ignore
            return window.Zone.current._properties[options.zoneIdentifier] === true;
        };
        options.routingEventListener = () => {
            options.bootstrappedNgZone.run(() => {
                // See https://github.com/single-spa/single-spa-angular/issues/86
                // Zone is unaware of the single-spa navigation change and so Angular change detection doesn't work
                // unless we tell Zone that something happened
            });
        };
    });
}
function mount(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        getContainerElementAndSetTemplate(options, props);
        const bootstrapPromise = options.bootstrapFunction(props);
        if (!(bootstrapPromise instanceof Promise)) {
            throw Error(`single-spa-angular: the options.bootstrapFunction must return a promise, but instead returned a '${typeof bootstrapPromise}' that is not a Promise`);
        }
        const module = yield bootstrapPromise;
        if (!module || typeof module.destroy !== 'function') {
            throw Error(`single-spa-angular: the options.bootstrapFunction returned a promise that did not resolve with a valid Angular module. Did you call platformBrowserDynamic().bootstrapModule() correctly?`);
        }
        const singleSpaPlatformLocation = module.injector.get(SingleSpaPlatformLocation, null);
        const ngZoneEnabled = options.NgZone !== 'noop';
        // The user has to provide `BrowserPlatformLocation` only if his application uses routing.
        // So if he provided `Router` but didn't provide `BrowserPlatformLocation` then we have to inform him.
        // Also `getSingleSpaExtraProviders()` function should be called only if the user doesn't use
        // `zone-less` change detection, if `NgZone` is `noop` then we can skip it.
        if (ngZoneEnabled && options.Router && singleSpaPlatformLocation === null) {
            throw new Error(`
      single-spa-angular: could not retrieve extra providers from the platform injector. Did you call platformBrowserDynamic(getSingleSpaExtraProviders()).bootstrapModule()?
    `);
        }
        const bootstrappedOptions = options;
        if (ngZoneEnabled) {
            const ngZone = module.injector.get(options.NgZone);
            const zoneIdentifier = bootstrappedOptions.zoneIdentifier;
            // `NgZone` can be enabled but routing may not be used thus `getSingleSpaExtraProviders()`
            // function was not called.
            if (singleSpaPlatformLocation !== null) {
                skipLocationChangeOnNonImperativeRoutingTriggers(module, options);
                // Cleanup resources, especially remove event listeners thus they will not be added
                // twice when application gets bootstrapped the second time.
                module.onDestroy(() => {
                    singleSpaPlatformLocation.destroyApplication(zoneIdentifier);
                });
            }
            bootstrappedOptions.bootstrappedNgZone = ngZone;
            bootstrappedOptions.bootstrappedNgZone['_inner']._properties[zoneIdentifier] = true;
            window.addEventListener('single-spa:routing-event', bootstrappedOptions.routingEventListener);
        }
        bootstrappedOptions.bootstrappedModule = module;
        return module;
    });
}
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function unmount(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        if (options.Router) {
            // Workaround for https://github.com/angular/angular/issues/19079
            const router = options.bootstrappedModule.injector.get(options.Router);
            router.dispose();
        }
        if (options.routingEventListener) {
            window.removeEventListener('single-spa:routing-event', options.routingEventListener);
        }
        if (options.AnimationEngine) {
            /*
            The BrowserAnimationsModule does not clean up after itself :'(. When you unmount/destroy the main module, the
            BrowserAnimationsModule uses an AnimationRenderer thing to remove dom elements from the page. But the AnimationRenderer
            defers the actual work to the TransitionAnimationEngine to do this, and the TransitionAnimationEngine doesn't actually
            remove the dom node, but just calls "markElementAsRemoved()".
        
            See https://github.com/angular/angular/blob/db62ccf9eb46ee89366ade586365ea027bb93eb1/packages/animations/browser/src/render/transition_animation_engine.ts#L717
        
            What markAsRemovedDoes is put it into an array called "collectedLeaveElements", which is all the elements that should be removed
            after the DOM has had a chance to do any animations.
        
            See https://github.com/angular/angular/blob/master/packages/animations/browser/src/render/transition_animation_engine.ts#L525
        
            The actual dom nodes aren't removed until the TransitionAnimationEngine "flushes".
        
            See https://github.com/angular/angular/blob/db62ccf9eb46ee89366ade586365ea027bb93eb1/packages/animations/browser/src/render/transition_animation_engine.ts#L851
        
            Unfortunately, though, that "flush" will never happen, since the entire module is being destroyed and there will be no more flushes.
            So what we do in this code is force one more flush of the animations after the module is destroyed.
        
            Ideally, we would do this by getting the TransitionAnimationEngine directly and flushing it. Unfortunately, though, it's private class
            that cannot be imported and is not provided to the dependency injector. So, instead, we get its wrapper class, AnimationEngine, and then
            access its private variable reference to the TransitionAnimationEngine so that we can call flush.
            */
            const animationEngine = options.bootstrappedModule.injector.get(options.AnimationEngine);
            animationEngine._transitionEngine.flush();
        }
        options.bootstrappedModule.destroy();
        delete options.bootstrappedModule;
        // This is an issue. Issue has been created and Angular team is working on the fix:
        // https://github.com/angular/angular/issues/36449
        removeApplicationFromDOMIfIvyEnabled(options, props);
    });
}
function skipLocationChangeOnNonImperativeRoutingTriggers(module, options) {
    if (!options.NavigationStart) {
        // As discussed we don't do anything right now if the developer doesn't provide
        // `options.NavigationStart` since this might be a breaking change.
        return;
    }
    const router = module.injector.get(options.Router);
    const subscription = router.events.subscribe((event) => {
        if (event instanceof options.NavigationStart) {
            const currentNavigation = router.getCurrentNavigation();
            // This listener will be set up for each Angular application
            // that has routing capabilities.
            // We set `skipLocationChange` for each non-imperative navigation,
            // Angular router checks under the hood if it has to change
            // the browser URL or not.
            // If `skipLocationChange` is truthy then Angular router will not call
            // `setBrowserUrl()` which calls `history.replaceState()` and dispatches `popstate` event.
            if (currentNavigation.trigger !== 'imperative') {
                currentNavigation.extras.skipLocationChange = true;
                currentNavigation.extras.replaceUrl = false;
            }
        }
    });
    module.onDestroy(() => {
        subscription.unsubscribe();
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2luZ2xlLXNwYS1hbmd1bGFyLmpzIiwic291cmNlUm9vdCI6Ii9Vc2Vycy9qb2VsZGVubmluZy9jb2RlL3NpbmdsZS1zcGEtYW5ndWxhci9saWJzL3NpbmdsZS1zcGEtYW5ndWxhci8iLCJzb3VyY2VzIjpbInNyYy9zaW5nbGUtc3BhLWFuZ3VsYXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUdBLE9BQU8sRUFDTCxpQ0FBaUMsRUFDakMsb0NBQW9DLEdBQ3JDLE1BQU0sOEJBQThCLENBQUM7QUFFdEMsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFHOUQsTUFBTSxjQUFjLEdBQUc7SUFDckIsNkRBQTZEO0lBQzdELE1BQU0sRUFBRSxJQUFLO0lBQ2IsaUJBQWlCLEVBQUUsSUFBSztJQUN4QixRQUFRLEVBQUUsSUFBSztJQUNmLG1CQUFtQjtJQUNuQixNQUFNLEVBQUUsU0FBUztJQUNqQixnQkFBZ0IsRUFBRSxTQUFTO0lBQzNCLGVBQWUsRUFBRSxTQUFTO0lBQzFCLGNBQWMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFO0NBQ3hDLENBQUM7QUFFRixNQUFNLFVBQVUsZ0JBQWdCLENBQUksV0FBdUM7SUFDekUsSUFBSSxPQUFPLFdBQVcsS0FBSyxRQUFRLEVBQUU7UUFDbkMsTUFBTSxLQUFLLENBQUMsb0RBQW9ELENBQUMsQ0FBQztLQUNuRTtJQUVELE1BQU0sT0FBTyxtQ0FDUixjQUFjLEdBQ2QsV0FBVyxDQUNmLENBQUM7SUFFRixJQUFJLE9BQU8sT0FBTyxDQUFDLGlCQUFpQixLQUFLLFVBQVUsRUFBRTtRQUNuRCxNQUFNLEtBQUssQ0FBQyxnRUFBZ0UsQ0FBQyxDQUFDO0tBQy9FO0lBRUQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO1FBQ3hDLE1BQU0sS0FBSyxDQUFDLDJEQUEyRCxDQUFDLENBQUM7S0FDMUU7SUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtRQUNuQixNQUFNLEtBQUssQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0tBQ3BFO0lBRUQsSUFBSSxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRTtRQUM5Qyw4RUFBOEU7UUFDOUUsd0JBQXdCO1FBQ3hCLE9BQU8sQ0FBQyxJQUFJLENBQUMsOERBQThELENBQUMsQ0FBQztLQUM5RTtJQUVELE9BQU87UUFDTCxTQUFTLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBOEMsQ0FBQztRQUMvRSxLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO1FBQ2hDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUE4QyxDQUFDO1FBQzNFLE1BQU0sRUFBRSxPQUFPLENBQUMsY0FBYztLQUMvQixDQUFDO0FBQ0osQ0FBQztBQUVELFNBQWUsU0FBUyxDQUFDLE9BQTRDLEVBQUUsS0FBVTs7UUFDL0UsdUZBQXVGO1FBQ3ZGLDZDQUE2QztRQUM3Qyw2Q0FBNkM7UUFDN0MsSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRTtZQUM3QixPQUFPO1NBQ1I7UUFFRCx5R0FBeUc7UUFDekcsT0FBTyxDQUFDLGNBQWMsR0FBRyxzQkFBc0IsS0FBSyxDQUFDLElBQUksSUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFN0Usc0dBQXNHO1FBQ3RHLHVFQUF1RTtRQUN2RSw4REFBOEQ7UUFDOUQsMkhBQTJIO1FBQzNILDhIQUE4SDtRQUM5SCxPQUFPLENBQUMsTUFBTSxDQUFDLGVBQWUsR0FBRyxHQUFHLEVBQUU7WUFDcEMsYUFBYTtZQUNiLE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsS0FBSyxJQUFJLENBQUM7UUFDMUUsQ0FBQyxDQUFDO1FBRUYsT0FBTyxDQUFDLG9CQUFvQixHQUFHLEdBQUcsRUFBRTtZQUNsQyxPQUFPLENBQUMsa0JBQW1CLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRTtnQkFDbkMsaUVBQWlFO2dCQUNqRSxtR0FBbUc7Z0JBQ25HLDhDQUE4QztZQUNoRCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQztJQUNKLENBQUM7Q0FBQTtBQUVELFNBQWUsS0FBSyxDQUFDLE9BQWdDLEVBQUUsS0FBVTs7UUFDL0QsaUNBQWlDLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRWxELE1BQU0sZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTFELElBQUksQ0FBQyxDQUFDLGdCQUFnQixZQUFZLE9BQU8sQ0FBQyxFQUFFO1lBQzFDLE1BQU0sS0FBSyxDQUNULG9HQUFvRyxPQUFPLGdCQUFnQix5QkFBeUIsQ0FDckosQ0FBQztTQUNIO1FBRUQsTUFBTSxNQUFNLEdBQXFCLE1BQU0sZ0JBQWdCLENBQUM7UUFFeEQsSUFBSSxDQUFDLE1BQU0sSUFBSSxPQUFPLE1BQU0sQ0FBQyxPQUFPLEtBQUssVUFBVSxFQUFFO1lBQ25ELE1BQU0sS0FBSyxDQUNULDJMQUEyTCxDQUM1TCxDQUFDO1NBQ0g7UUFFRCxNQUFNLHlCQUF5QixHQUFxQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FDckYseUJBQXlCLEVBQ3pCLElBQUksQ0FDTCxDQUFDO1FBRUYsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLE1BQU0sS0FBSyxNQUFNLENBQUM7UUFFaEQsMEZBQTBGO1FBQzFGLHNHQUFzRztRQUN0Ryw2RkFBNkY7UUFDN0YsMkVBQTJFO1FBQzNFLElBQUksYUFBYSxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUkseUJBQXlCLEtBQUssSUFBSSxFQUFFO1lBQ3pFLE1BQU0sSUFBSSxLQUFLLENBQUM7O0tBRWYsQ0FBQyxDQUFDO1NBQ0o7UUFFRCxNQUFNLG1CQUFtQixHQUFHLE9BQThDLENBQUM7UUFFM0UsSUFBSSxhQUFhLEVBQUU7WUFDakIsTUFBTSxNQUFNLEdBQVcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNELE1BQU0sY0FBYyxHQUFXLG1CQUFtQixDQUFDLGNBQWUsQ0FBQztZQUVuRSwwRkFBMEY7WUFDMUYsMkJBQTJCO1lBQzNCLElBQUkseUJBQXlCLEtBQUssSUFBSSxFQUFFO2dCQUN0QyxnREFBZ0QsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBRWxFLG1GQUFtRjtnQkFDbkYsNERBQTREO2dCQUM1RCxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtvQkFDcEIseUJBQXlCLENBQUMsa0JBQWtCLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQy9ELENBQUMsQ0FBQyxDQUFDO2FBQ0o7WUFFRCxtQkFBbUIsQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUM7WUFDaEQsbUJBQW1CLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUNwRixNQUFNLENBQUMsZ0JBQWdCLENBQUMsMEJBQTBCLEVBQUUsbUJBQW1CLENBQUMsb0JBQXFCLENBQUMsQ0FBQztTQUNoRztRQUVELG1CQUFtQixDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQztRQUNoRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0NBQUE7QUFFRCw2REFBNkQ7QUFDN0QsU0FBZSxPQUFPLENBQUMsT0FBNEMsRUFBRSxLQUFVOztRQUM3RSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDbEIsaUVBQWlFO1lBQ2pFLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2RSxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDbEI7UUFFRCxJQUFJLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRTtZQUNoQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsMEJBQTBCLEVBQUUsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDdEY7UUFFRCxJQUFJLE9BQU8sQ0FBQyxlQUFlLEVBQUU7WUFDM0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2NBdUJFO1lBQ0YsTUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ3pGLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUMzQztRQUVELE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNyQyxPQUFPLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztRQUVsQyxtRkFBbUY7UUFDbkYsa0RBQWtEO1FBQ2xELG9DQUFvQyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2RCxDQUFDO0NBQUE7QUFFRCxTQUFTLGdEQUFnRCxDQUN2RCxNQUF3QixFQUN4QixPQUFnQztJQUVoQyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRTtRQUM1QiwrRUFBK0U7UUFDL0UsbUVBQW1FO1FBQ25FLE9BQU87S0FDUjtJQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuRCxNQUFNLFlBQVksR0FBaUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtRQUN4RSxJQUFJLEtBQUssWUFBWSxPQUFPLENBQUMsZUFBZ0IsRUFBRTtZQUM3QyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQ3hELDREQUE0RDtZQUM1RCxpQ0FBaUM7WUFDakMsa0VBQWtFO1lBQ2xFLDJEQUEyRDtZQUMzRCwwQkFBMEI7WUFDMUIsc0VBQXNFO1lBQ3RFLDBGQUEwRjtZQUMxRixJQUFJLGlCQUFpQixDQUFDLE9BQU8sS0FBSyxZQUFZLEVBQUU7Z0JBQzlDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7Z0JBQ25ELGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2FBQzdDO1NBQ0Y7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUVILE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1FBQ3BCLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUM3QixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZVJlZiwgTmdab25lIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IExpZmVDeWNsZXMgfSBmcm9tICdzaW5nbGUtc3BhJztcbmltcG9ydCB7XG4gIGdldENvbnRhaW5lckVsZW1lbnRBbmRTZXRUZW1wbGF0ZSxcbiAgcmVtb3ZlQXBwbGljYXRpb25Gcm9tRE9NSWZJdnlFbmFibGVkLFxufSBmcm9tICdzaW5nbGUtc3BhLWFuZ3VsYXIvaW50ZXJuYWxzJztcblxuaW1wb3J0IHsgU2luZ2xlU3BhUGxhdGZvcm1Mb2NhdGlvbiB9IGZyb20gJy4vZXh0cmEtcHJvdmlkZXJzJztcbmltcG9ydCB7IFNpbmdsZVNwYUFuZ3VsYXJPcHRpb25zLCBCb290c3RyYXBwZWRTaW5nbGVTcGFBbmd1bGFyT3B0aW9ucyB9IGZyb20gJy4vdHlwZXMnO1xuXG5jb25zdCBkZWZhdWx0T3B0aW9ucyA9IHtcbiAgLy8gUmVxdWlyZWQgb3B0aW9ucyB0aGF0IHdpbGwgYmUgc2V0IGJ5IHRoZSBsaWJyYXJ5IGNvbnN1bWVyLlxuICBOZ1pvbmU6IG51bGwhLFxuICBib290c3RyYXBGdW5jdGlvbjogbnVsbCEsXG4gIHRlbXBsYXRlOiBudWxsISxcbiAgLy8gT3B0aW9uYWwgb3B0aW9uc1xuICBSb3V0ZXI6IHVuZGVmaW5lZCxcbiAgZG9tRWxlbWVudEdldHRlcjogdW5kZWZpbmVkLCAvLyBvbmx5IG9wdGlvbmFsIGlmIHlvdSBwcm92aWRlIGEgZG9tRWxlbWVudEdldHRlciBhcyBhIGN1c3RvbSBwcm9wXG4gIEFuaW1hdGlvbkVuZ2luZTogdW5kZWZpbmVkLFxuICB1cGRhdGVGdW5jdGlvbjogKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCksXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gc2luZ2xlU3BhQW5ndWxhcjxUPih1c2VyT3B0aW9uczogU2luZ2xlU3BhQW5ndWxhck9wdGlvbnM8VD4pOiBMaWZlQ3ljbGVzPFQ+IHtcbiAgaWYgKHR5cGVvZiB1c2VyT3B0aW9ucyAhPT0gJ29iamVjdCcpIHtcbiAgICB0aHJvdyBFcnJvcignc2luZ2xlLXNwYS1hbmd1bGFyIHJlcXVpcmVzIGEgY29uZmlndXJhdGlvbiBvYmplY3QnKTtcbiAgfVxuXG4gIGNvbnN0IG9wdGlvbnM6IFNpbmdsZVNwYUFuZ3VsYXJPcHRpb25zID0ge1xuICAgIC4uLmRlZmF1bHRPcHRpb25zLFxuICAgIC4uLnVzZXJPcHRpb25zLFxuICB9O1xuXG4gIGlmICh0eXBlb2Ygb3B0aW9ucy5ib290c3RyYXBGdW5jdGlvbiAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHRocm93IEVycm9yKCdzaW5nbGUtc3BhLWFuZ3VsYXIgbXVzdCBiZSBwYXNzZWQgYW4gb3B0aW9ucy5ib290c3RyYXBGdW5jdGlvbicpO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBvcHRpb25zLnRlbXBsYXRlICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IEVycm9yKCdzaW5nbGUtc3BhLWFuZ3VsYXIgbXVzdCBiZSBwYXNzZWQgb3B0aW9ucy50ZW1wbGF0ZSBzdHJpbmcnKTtcbiAgfVxuXG4gIGlmICghb3B0aW9ucy5OZ1pvbmUpIHtcbiAgICB0aHJvdyBFcnJvcihgc2luZ2xlLXNwYS1hbmd1bGFyIG11c3QgYmUgcGFzc2VkIHRoZSBOZ1pvbmUgb3B0aW9uYCk7XG4gIH1cblxuICBpZiAob3B0aW9ucy5Sb3V0ZXIgJiYgIW9wdGlvbnMuTmF2aWdhdGlvblN0YXJ0KSB7XG4gICAgLy8gV2UgY2FsbCBgY29uc29sZS53YXJuYCBleGNlcHQgb2YgdGhyb3dpbmcgYG5ldyBFcnJvcigpYCBzaW5jZSB0aGlzIHdpbGwgbm90XG4gICAgLy8gYmUgYSBicmVha2luZyBjaGFuZ2UuXG4gICAgY29uc29sZS53YXJuKGBzaW5nbGUtc3BhLWFuZ3VsYXIgbXVzdCBiZSBwYXNzZWQgdGhlIE5hdmlnYXRpb25TdGFydCBvcHRpb25gKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgYm9vdHN0cmFwOiBib290c3RyYXAuYmluZChudWxsLCBvcHRpb25zIGFzIEJvb3RzdHJhcHBlZFNpbmdsZVNwYUFuZ3VsYXJPcHRpb25zKSxcbiAgICBtb3VudDogbW91bnQuYmluZChudWxsLCBvcHRpb25zKSxcbiAgICB1bm1vdW50OiB1bm1vdW50LmJpbmQobnVsbCwgb3B0aW9ucyBhcyBCb290c3RyYXBwZWRTaW5nbGVTcGFBbmd1bGFyT3B0aW9ucyksXG4gICAgdXBkYXRlOiBvcHRpb25zLnVwZGF0ZUZ1bmN0aW9uLFxuICB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBib290c3RyYXAob3B0aW9uczogQm9vdHN0cmFwcGVkU2luZ2xlU3BhQW5ndWxhck9wdGlvbnMsIHByb3BzOiBhbnkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gQW5ndWxhciBwcm92aWRlcyBhbiBvcHBvcnR1bml0eSB0byBkZXZlbG9wIGB6b25lLWxlc3NgIGFwcGxpY2F0aW9uLCB3aGVyZSBkZXZlbG9wZXJzXG4gIC8vIGhhdmUgdG8gdHJpZ2dlciBjaGFuZ2UgZGV0ZWN0aW9uIG1hbnVhbGx5LlxuICAvLyBTZWUgaHR0cHM6Ly9hbmd1bGFyLmlvL2d1aWRlL3pvbmUjbm9vcHpvbmVcbiAgaWYgKG9wdGlvbnMuTmdab25lID09PSAnbm9vcCcpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBJbiBvcmRlciBmb3IgbXVsdGlwbGUgQW5ndWxhciBhcHBzIHRvIHdvcmsgY29uY3VycmVudGx5IG9uIGEgcGFnZSwgdGhleSBlYWNoIG5lZWQgYSB1bmlxdWUgaWRlbnRpZmllci5cbiAgb3B0aW9ucy56b25lSWRlbnRpZmllciA9IGBzaW5nbGUtc3BhLWFuZ3VsYXI6JHtwcm9wcy5uYW1lIHx8IHByb3BzLmFwcE5hbWV9YDtcblxuICAvLyBUaGlzIGlzIGEgaGFjaywgc2luY2UgTmdab25lIGRvZXNuJ3QgYWxsb3cgeW91IHRvIGNvbmZpZ3VyZSB0aGUgcHJvcGVydHkgdGhhdCBpZGVudGlmaWVzIHlvdXIgem9uZS5cbiAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9QbGFjZU1lLVNBUy9zaW5nbGUtc3BhLWFuZ3VsYXItY2xpL2lzc3Vlcy8zMyxcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3NpbmdsZS1zcGEvc2luZ2xlLXNwYS1hbmd1bGFyL2lzc3Vlcy80NyxcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9ibG9iL2ExNGRjMmQ3YTQ4MjFhMTlmMjBhOTU0NzA1M2E1NzM0Nzk4ZjU0MWUvcGFja2FnZXMvY29yZS9zcmMvem9uZS9uZ196b25lLnRzI0wxNDQsXG4gIC8vIGFuZCBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvYTE0ZGMyZDdhNDgyMWExOWYyMGE5NTQ3MDUzYTU3MzQ3OThmNTQxZS9wYWNrYWdlcy9jb3JlL3NyYy96b25lL25nX3pvbmUudHMjTDI1N1xuICBvcHRpb25zLk5nWm9uZS5pc0luQW5ndWxhclpvbmUgPSAoKSA9PiB7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHJldHVybiB3aW5kb3cuWm9uZS5jdXJyZW50Ll9wcm9wZXJ0aWVzW29wdGlvbnMuem9uZUlkZW50aWZpZXJdID09PSB0cnVlO1xuICB9O1xuXG4gIG9wdGlvbnMucm91dGluZ0V2ZW50TGlzdGVuZXIgPSAoKSA9PiB7XG4gICAgb3B0aW9ucy5ib290c3RyYXBwZWROZ1pvbmUhLnJ1bigoKSA9PiB7XG4gICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3NpbmdsZS1zcGEvc2luZ2xlLXNwYS1hbmd1bGFyL2lzc3Vlcy84NlxuICAgICAgLy8gWm9uZSBpcyB1bmF3YXJlIG9mIHRoZSBzaW5nbGUtc3BhIG5hdmlnYXRpb24gY2hhbmdlIGFuZCBzbyBBbmd1bGFyIGNoYW5nZSBkZXRlY3Rpb24gZG9lc24ndCB3b3JrXG4gICAgICAvLyB1bmxlc3Mgd2UgdGVsbCBab25lIHRoYXQgc29tZXRoaW5nIGhhcHBlbmVkXG4gICAgfSk7XG4gIH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1vdW50KG9wdGlvbnM6IFNpbmdsZVNwYUFuZ3VsYXJPcHRpb25zLCBwcm9wczogYW55KTogUHJvbWlzZTxOZ01vZHVsZVJlZjxhbnk+PiB7XG4gIGdldENvbnRhaW5lckVsZW1lbnRBbmRTZXRUZW1wbGF0ZShvcHRpb25zLCBwcm9wcyk7XG5cbiAgY29uc3QgYm9vdHN0cmFwUHJvbWlzZSA9IG9wdGlvbnMuYm9vdHN0cmFwRnVuY3Rpb24ocHJvcHMpO1xuXG4gIGlmICghKGJvb3RzdHJhcFByb21pc2UgaW5zdGFuY2VvZiBQcm9taXNlKSkge1xuICAgIHRocm93IEVycm9yKFxuICAgICAgYHNpbmdsZS1zcGEtYW5ndWxhcjogdGhlIG9wdGlvbnMuYm9vdHN0cmFwRnVuY3Rpb24gbXVzdCByZXR1cm4gYSBwcm9taXNlLCBidXQgaW5zdGVhZCByZXR1cm5lZCBhICcke3R5cGVvZiBib290c3RyYXBQcm9taXNlfScgdGhhdCBpcyBub3QgYSBQcm9taXNlYCxcbiAgICApO1xuICB9XG5cbiAgY29uc3QgbW9kdWxlOiBOZ01vZHVsZVJlZjxhbnk+ID0gYXdhaXQgYm9vdHN0cmFwUHJvbWlzZTtcblxuICBpZiAoIW1vZHVsZSB8fCB0eXBlb2YgbW9kdWxlLmRlc3Ryb3kgIT09ICdmdW5jdGlvbicpIHtcbiAgICB0aHJvdyBFcnJvcihcbiAgICAgIGBzaW5nbGUtc3BhLWFuZ3VsYXI6IHRoZSBvcHRpb25zLmJvb3RzdHJhcEZ1bmN0aW9uIHJldHVybmVkIGEgcHJvbWlzZSB0aGF0IGRpZCBub3QgcmVzb2x2ZSB3aXRoIGEgdmFsaWQgQW5ndWxhciBtb2R1bGUuIERpZCB5b3UgY2FsbCBwbGF0Zm9ybUJyb3dzZXJEeW5hbWljKCkuYm9vdHN0cmFwTW9kdWxlKCkgY29ycmVjdGx5P2AsXG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IHNpbmdsZVNwYVBsYXRmb3JtTG9jYXRpb246IFNpbmdsZVNwYVBsYXRmb3JtTG9jYXRpb24gfCBudWxsID0gbW9kdWxlLmluamVjdG9yLmdldChcbiAgICBTaW5nbGVTcGFQbGF0Zm9ybUxvY2F0aW9uLFxuICAgIG51bGwsXG4gICk7XG5cbiAgY29uc3Qgbmdab25lRW5hYmxlZCA9IG9wdGlvbnMuTmdab25lICE9PSAnbm9vcCc7XG5cbiAgLy8gVGhlIHVzZXIgaGFzIHRvIHByb3ZpZGUgYEJyb3dzZXJQbGF0Zm9ybUxvY2F0aW9uYCBvbmx5IGlmIGhpcyBhcHBsaWNhdGlvbiB1c2VzIHJvdXRpbmcuXG4gIC8vIFNvIGlmIGhlIHByb3ZpZGVkIGBSb3V0ZXJgIGJ1dCBkaWRuJ3QgcHJvdmlkZSBgQnJvd3NlclBsYXRmb3JtTG9jYXRpb25gIHRoZW4gd2UgaGF2ZSB0byBpbmZvcm0gaGltLlxuICAvLyBBbHNvIGBnZXRTaW5nbGVTcGFFeHRyYVByb3ZpZGVycygpYCBmdW5jdGlvbiBzaG91bGQgYmUgY2FsbGVkIG9ubHkgaWYgdGhlIHVzZXIgZG9lc24ndCB1c2VcbiAgLy8gYHpvbmUtbGVzc2AgY2hhbmdlIGRldGVjdGlvbiwgaWYgYE5nWm9uZWAgaXMgYG5vb3BgIHRoZW4gd2UgY2FuIHNraXAgaXQuXG4gIGlmIChuZ1pvbmVFbmFibGVkICYmIG9wdGlvbnMuUm91dGVyICYmIHNpbmdsZVNwYVBsYXRmb3JtTG9jYXRpb24gPT09IG51bGwpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYFxuICAgICAgc2luZ2xlLXNwYS1hbmd1bGFyOiBjb3VsZCBub3QgcmV0cmlldmUgZXh0cmEgcHJvdmlkZXJzIGZyb20gdGhlIHBsYXRmb3JtIGluamVjdG9yLiBEaWQgeW91IGNhbGwgcGxhdGZvcm1Ccm93c2VyRHluYW1pYyhnZXRTaW5nbGVTcGFFeHRyYVByb3ZpZGVycygpKS5ib290c3RyYXBNb2R1bGUoKT9cbiAgICBgKTtcbiAgfVxuXG4gIGNvbnN0IGJvb3RzdHJhcHBlZE9wdGlvbnMgPSBvcHRpb25zIGFzIEJvb3RzdHJhcHBlZFNpbmdsZVNwYUFuZ3VsYXJPcHRpb25zO1xuXG4gIGlmIChuZ1pvbmVFbmFibGVkKSB7XG4gICAgY29uc3Qgbmdab25lOiBOZ1pvbmUgPSBtb2R1bGUuaW5qZWN0b3IuZ2V0KG9wdGlvbnMuTmdab25lKTtcbiAgICBjb25zdCB6b25lSWRlbnRpZmllcjogc3RyaW5nID0gYm9vdHN0cmFwcGVkT3B0aW9ucy56b25lSWRlbnRpZmllciE7XG5cbiAgICAvLyBgTmdab25lYCBjYW4gYmUgZW5hYmxlZCBidXQgcm91dGluZyBtYXkgbm90IGJlIHVzZWQgdGh1cyBgZ2V0U2luZ2xlU3BhRXh0cmFQcm92aWRlcnMoKWBcbiAgICAvLyBmdW5jdGlvbiB3YXMgbm90IGNhbGxlZC5cbiAgICBpZiAoc2luZ2xlU3BhUGxhdGZvcm1Mb2NhdGlvbiAhPT0gbnVsbCkge1xuICAgICAgc2tpcExvY2F0aW9uQ2hhbmdlT25Ob25JbXBlcmF0aXZlUm91dGluZ1RyaWdnZXJzKG1vZHVsZSwgb3B0aW9ucyk7XG5cbiAgICAgIC8vIENsZWFudXAgcmVzb3VyY2VzLCBlc3BlY2lhbGx5IHJlbW92ZSBldmVudCBsaXN0ZW5lcnMgdGh1cyB0aGV5IHdpbGwgbm90IGJlIGFkZGVkXG4gICAgICAvLyB0d2ljZSB3aGVuIGFwcGxpY2F0aW9uIGdldHMgYm9vdHN0cmFwcGVkIHRoZSBzZWNvbmQgdGltZS5cbiAgICAgIG1vZHVsZS5vbkRlc3Ryb3koKCkgPT4ge1xuICAgICAgICBzaW5nbGVTcGFQbGF0Zm9ybUxvY2F0aW9uLmRlc3Ryb3lBcHBsaWNhdGlvbih6b25lSWRlbnRpZmllcik7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBib290c3RyYXBwZWRPcHRpb25zLmJvb3RzdHJhcHBlZE5nWm9uZSA9IG5nWm9uZTtcbiAgICBib290c3RyYXBwZWRPcHRpb25zLmJvb3RzdHJhcHBlZE5nWm9uZVsnX2lubmVyJ10uX3Byb3BlcnRpZXNbem9uZUlkZW50aWZpZXJdID0gdHJ1ZTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2luZ2xlLXNwYTpyb3V0aW5nLWV2ZW50JywgYm9vdHN0cmFwcGVkT3B0aW9ucy5yb3V0aW5nRXZlbnRMaXN0ZW5lciEpO1xuICB9XG5cbiAgYm9vdHN0cmFwcGVkT3B0aW9ucy5ib290c3RyYXBwZWRNb2R1bGUgPSBtb2R1bGU7XG4gIHJldHVybiBtb2R1bGU7XG59XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbmFzeW5jIGZ1bmN0aW9uIHVubW91bnQob3B0aW9uczogQm9vdHN0cmFwcGVkU2luZ2xlU3BhQW5ndWxhck9wdGlvbnMsIHByb3BzOiBhbnkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKG9wdGlvbnMuUm91dGVyKSB7XG4gICAgLy8gV29ya2Fyb3VuZCBmb3IgaHR0cHM6Ly9naXRodWIuY29tL2FuZ3VsYXIvYW5ndWxhci9pc3N1ZXMvMTkwNzlcbiAgICBjb25zdCByb3V0ZXIgPSBvcHRpb25zLmJvb3RzdHJhcHBlZE1vZHVsZS5pbmplY3Rvci5nZXQob3B0aW9ucy5Sb3V0ZXIpO1xuICAgIHJvdXRlci5kaXNwb3NlKCk7XG4gIH1cblxuICBpZiAob3B0aW9ucy5yb3V0aW5nRXZlbnRMaXN0ZW5lcikge1xuICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzaW5nbGUtc3BhOnJvdXRpbmctZXZlbnQnLCBvcHRpb25zLnJvdXRpbmdFdmVudExpc3RlbmVyKTtcbiAgfVxuXG4gIGlmIChvcHRpb25zLkFuaW1hdGlvbkVuZ2luZSkge1xuICAgIC8qXG4gICAgVGhlIEJyb3dzZXJBbmltYXRpb25zTW9kdWxlIGRvZXMgbm90IGNsZWFuIHVwIGFmdGVyIGl0c2VsZiA6JyguIFdoZW4geW91IHVubW91bnQvZGVzdHJveSB0aGUgbWFpbiBtb2R1bGUsIHRoZVxuICAgIEJyb3dzZXJBbmltYXRpb25zTW9kdWxlIHVzZXMgYW4gQW5pbWF0aW9uUmVuZGVyZXIgdGhpbmcgdG8gcmVtb3ZlIGRvbSBlbGVtZW50cyBmcm9tIHRoZSBwYWdlLiBCdXQgdGhlIEFuaW1hdGlvblJlbmRlcmVyXG4gICAgZGVmZXJzIHRoZSBhY3R1YWwgd29yayB0byB0aGUgVHJhbnNpdGlvbkFuaW1hdGlvbkVuZ2luZSB0byBkbyB0aGlzLCBhbmQgdGhlIFRyYW5zaXRpb25BbmltYXRpb25FbmdpbmUgZG9lc24ndCBhY3R1YWxseVxuICAgIHJlbW92ZSB0aGUgZG9tIG5vZGUsIGJ1dCBqdXN0IGNhbGxzIFwibWFya0VsZW1lbnRBc1JlbW92ZWQoKVwiLlxuXG4gICAgU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi9kYjYyY2NmOWViNDZlZTg5MzY2YWRlNTg2MzY1ZWEwMjdiYjkzZWIxL3BhY2thZ2VzL2FuaW1hdGlvbnMvYnJvd3Nlci9zcmMvcmVuZGVyL3RyYW5zaXRpb25fYW5pbWF0aW9uX2VuZ2luZS50cyNMNzE3XG5cbiAgICBXaGF0IG1hcmtBc1JlbW92ZWREb2VzIGlzIHB1dCBpdCBpbnRvIGFuIGFycmF5IGNhbGxlZCBcImNvbGxlY3RlZExlYXZlRWxlbWVudHNcIiwgd2hpY2ggaXMgYWxsIHRoZSBlbGVtZW50cyB0aGF0IHNob3VsZCBiZSByZW1vdmVkXG4gICAgYWZ0ZXIgdGhlIERPTSBoYXMgaGFkIGEgY2hhbmNlIHRvIGRvIGFueSBhbmltYXRpb25zLlxuXG4gICAgU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi9tYXN0ZXIvcGFja2FnZXMvYW5pbWF0aW9ucy9icm93c2VyL3NyYy9yZW5kZXIvdHJhbnNpdGlvbl9hbmltYXRpb25fZW5naW5lLnRzI0w1MjVcblxuICAgIFRoZSBhY3R1YWwgZG9tIG5vZGVzIGFyZW4ndCByZW1vdmVkIHVudGlsIHRoZSBUcmFuc2l0aW9uQW5pbWF0aW9uRW5naW5lIFwiZmx1c2hlc1wiLlxuXG4gICAgU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvYmxvYi9kYjYyY2NmOWViNDZlZTg5MzY2YWRlNTg2MzY1ZWEwMjdiYjkzZWIxL3BhY2thZ2VzL2FuaW1hdGlvbnMvYnJvd3Nlci9zcmMvcmVuZGVyL3RyYW5zaXRpb25fYW5pbWF0aW9uX2VuZ2luZS50cyNMODUxXG5cbiAgICBVbmZvcnR1bmF0ZWx5LCB0aG91Z2gsIHRoYXQgXCJmbHVzaFwiIHdpbGwgbmV2ZXIgaGFwcGVuLCBzaW5jZSB0aGUgZW50aXJlIG1vZHVsZSBpcyBiZWluZyBkZXN0cm95ZWQgYW5kIHRoZXJlIHdpbGwgYmUgbm8gbW9yZSBmbHVzaGVzLlxuICAgIFNvIHdoYXQgd2UgZG8gaW4gdGhpcyBjb2RlIGlzIGZvcmNlIG9uZSBtb3JlIGZsdXNoIG9mIHRoZSBhbmltYXRpb25zIGFmdGVyIHRoZSBtb2R1bGUgaXMgZGVzdHJveWVkLlxuXG4gICAgSWRlYWxseSwgd2Ugd291bGQgZG8gdGhpcyBieSBnZXR0aW5nIHRoZSBUcmFuc2l0aW9uQW5pbWF0aW9uRW5naW5lIGRpcmVjdGx5IGFuZCBmbHVzaGluZyBpdC4gVW5mb3J0dW5hdGVseSwgdGhvdWdoLCBpdCdzIHByaXZhdGUgY2xhc3NcbiAgICB0aGF0IGNhbm5vdCBiZSBpbXBvcnRlZCBhbmQgaXMgbm90IHByb3ZpZGVkIHRvIHRoZSBkZXBlbmRlbmN5IGluamVjdG9yLiBTbywgaW5zdGVhZCwgd2UgZ2V0IGl0cyB3cmFwcGVyIGNsYXNzLCBBbmltYXRpb25FbmdpbmUsIGFuZCB0aGVuXG4gICAgYWNjZXNzIGl0cyBwcml2YXRlIHZhcmlhYmxlIHJlZmVyZW5jZSB0byB0aGUgVHJhbnNpdGlvbkFuaW1hdGlvbkVuZ2luZSBzbyB0aGF0IHdlIGNhbiBjYWxsIGZsdXNoLlxuICAgICovXG4gICAgY29uc3QgYW5pbWF0aW9uRW5naW5lID0gb3B0aW9ucy5ib290c3RyYXBwZWRNb2R1bGUuaW5qZWN0b3IuZ2V0KG9wdGlvbnMuQW5pbWF0aW9uRW5naW5lKTtcbiAgICBhbmltYXRpb25FbmdpbmUuX3RyYW5zaXRpb25FbmdpbmUuZmx1c2goKTtcbiAgfVxuXG4gIG9wdGlvbnMuYm9vdHN0cmFwcGVkTW9kdWxlLmRlc3Ryb3koKTtcbiAgZGVsZXRlIG9wdGlvbnMuYm9vdHN0cmFwcGVkTW9kdWxlO1xuXG4gIC8vIFRoaXMgaXMgYW4gaXNzdWUuIElzc3VlIGhhcyBiZWVuIGNyZWF0ZWQgYW5kIEFuZ3VsYXIgdGVhbSBpcyB3b3JraW5nIG9uIHRoZSBmaXg6XG4gIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9hbmd1bGFyL2FuZ3VsYXIvaXNzdWVzLzM2NDQ5XG4gIHJlbW92ZUFwcGxpY2F0aW9uRnJvbURPTUlmSXZ5RW5hYmxlZChvcHRpb25zLCBwcm9wcyk7XG59XG5cbmZ1bmN0aW9uIHNraXBMb2NhdGlvbkNoYW5nZU9uTm9uSW1wZXJhdGl2ZVJvdXRpbmdUcmlnZ2VycyhcbiAgbW9kdWxlOiBOZ01vZHVsZVJlZjxhbnk+LFxuICBvcHRpb25zOiBTaW5nbGVTcGFBbmd1bGFyT3B0aW9ucyxcbik6IHZvaWQge1xuICBpZiAoIW9wdGlvbnMuTmF2aWdhdGlvblN0YXJ0KSB7XG4gICAgLy8gQXMgZGlzY3Vzc2VkIHdlIGRvbid0IGRvIGFueXRoaW5nIHJpZ2h0IG5vdyBpZiB0aGUgZGV2ZWxvcGVyIGRvZXNuJ3QgcHJvdmlkZVxuICAgIC8vIGBvcHRpb25zLk5hdmlnYXRpb25TdGFydGAgc2luY2UgdGhpcyBtaWdodCBiZSBhIGJyZWFraW5nIGNoYW5nZS5cbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCByb3V0ZXIgPSBtb2R1bGUuaW5qZWN0b3IuZ2V0KG9wdGlvbnMuUm91dGVyKTtcbiAgY29uc3Qgc3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb24gPSByb3V0ZXIuZXZlbnRzLnN1YnNjcmliZSgoZXZlbnQ6IGFueSkgPT4ge1xuICAgIGlmIChldmVudCBpbnN0YW5jZW9mIG9wdGlvbnMuTmF2aWdhdGlvblN0YXJ0ISkge1xuICAgICAgY29uc3QgY3VycmVudE5hdmlnYXRpb24gPSByb3V0ZXIuZ2V0Q3VycmVudE5hdmlnYXRpb24oKTtcbiAgICAgIC8vIFRoaXMgbGlzdGVuZXIgd2lsbCBiZSBzZXQgdXAgZm9yIGVhY2ggQW5ndWxhciBhcHBsaWNhdGlvblxuICAgICAgLy8gdGhhdCBoYXMgcm91dGluZyBjYXBhYmlsaXRpZXMuXG4gICAgICAvLyBXZSBzZXQgYHNraXBMb2NhdGlvbkNoYW5nZWAgZm9yIGVhY2ggbm9uLWltcGVyYXRpdmUgbmF2aWdhdGlvbixcbiAgICAgIC8vIEFuZ3VsYXIgcm91dGVyIGNoZWNrcyB1bmRlciB0aGUgaG9vZCBpZiBpdCBoYXMgdG8gY2hhbmdlXG4gICAgICAvLyB0aGUgYnJvd3NlciBVUkwgb3Igbm90LlxuICAgICAgLy8gSWYgYHNraXBMb2NhdGlvbkNoYW5nZWAgaXMgdHJ1dGh5IHRoZW4gQW5ndWxhciByb3V0ZXIgd2lsbCBub3QgY2FsbFxuICAgICAgLy8gYHNldEJyb3dzZXJVcmwoKWAgd2hpY2ggY2FsbHMgYGhpc3RvcnkucmVwbGFjZVN0YXRlKClgIGFuZCBkaXNwYXRjaGVzIGBwb3BzdGF0ZWAgZXZlbnQuXG4gICAgICBpZiAoY3VycmVudE5hdmlnYXRpb24udHJpZ2dlciAhPT0gJ2ltcGVyYXRpdmUnKSB7XG4gICAgICAgIGN1cnJlbnROYXZpZ2F0aW9uLmV4dHJhcy5za2lwTG9jYXRpb25DaGFuZ2UgPSB0cnVlO1xuICAgICAgICBjdXJyZW50TmF2aWdhdGlvbi5leHRyYXMucmVwbGFjZVVybCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG5cbiAgbW9kdWxlLm9uRGVzdHJveSgoKSA9PiB7XG4gICAgc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gIH0pO1xufVxuIl19