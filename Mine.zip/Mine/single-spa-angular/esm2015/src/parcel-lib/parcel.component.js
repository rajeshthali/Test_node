import { Component, Input, ElementRef } from '@angular/core';
export class ParcelComponent {
    // eslint-disable-next-line @typescript-eslint/no-parameter-properties
    constructor(host) {
        this.host = host;
        this.onParcelMount = null;
        this.wrapWith = 'div';
        this.customProps = {};
        this.appendTo = null;
        this.handleError = (error) => console.error(error);
        this.createdDomElement = null;
        this.hasError = false;
        this.unmounted = true;
    }
    ngOnInit() {
        if (!this.config) {
            throw new Error(`single-spa-angular's Parcel component requires the [config] binding to either be a parcel config or a loading function that returns a promise. See https://github.com/CanopyTax/single-spa-angular`);
        }
        this.addThingToDo('mount', () => {
            const mountParcel = this.mountParcel;
            if (!mountParcel) {
                throw new Error(`
				  <parcel> was not passed a [mountParcel] binding.
				  If you are using <parcel> within a module that is not a single-spa application, you will need to import mountRootParcel from single-spa and pass it into <parcel> as a [mountParcel] binding
				`);
            }
            let domElement;
            if (this.appendTo) {
                this.createdDomElement = domElement = document.createElement(this.wrapWith);
                this.appendTo.appendChild(domElement);
            }
            else {
                this.createdDomElement = domElement = document.createElement(this.wrapWith);
                // Except of having `@ViewChild` we can simply get the first child element.
                const parcelDiv = this.host.nativeElement.children[0];
                parcelDiv.appendChild(domElement);
            }
            this.parcel = mountParcel(this.config, Object.assign({ domElement }, this.customProps));
            if (this.onParcelMount) {
                this.parcel.mountPromise.then(this.onParcelMount);
            }
            this.unmounted = false;
            return this.parcel.mountPromise;
        });
    }
    ngOnChanges() {
        this.addThingToDo('update', () => {
            if (this.parcel && this.parcel.update) {
                return this.parcel.update(this.customProps);
            }
        });
    }
    ngOnDestroy() {
        this.addThingToDo('unmount', () => {
            if (this.parcel && this.parcel.getStatus() === 'MOUNTED') {
                return this.parcel.unmount();
            }
        });
        if (this.createdDomElement) {
            this.createdDomElement.parentNode.removeChild(this.createdDomElement);
        }
        this.unmounted = true;
    }
    addThingToDo(action, thing) {
        if (this.hasError && action !== 'unmount') {
            // In an error state, we don't do anything anymore except for unmounting
            return;
        }
        this.nextThingToDo = (this.nextThingToDo || Promise.resolve())
            .then((...args) => {
            if (this.unmounted && action !== 'unmount') {
                // Never do anything once the angular component unmounts
                return;
            }
            return thing(...args);
        })
            .catch(error => {
            this.nextThingToDo = Promise.resolve(); // reset so we don't .then() the bad promise again
            this.hasError = true;
            if (error && error.message) {
                error.message = `During '${action}', parcel threw an error: ${error.message}`;
            }
            if (typeof this.handleError === 'function') {
                this.handleError(error);
            }
            else {
                setTimeout(() => {
                    throw error;
                });
            }
            // No more things to do should be done -- the parcel is in an error state
            throw error;
        });
    }
}
ParcelComponent.decorators = [
    { type: Component, args: [{
                selector: 'parcel',
                template: '<div></div>'
            },] }
];
ParcelComponent.ctorParameters = () => [
    { type: ElementRef }
];
ParcelComponent.propDecorators = {
    config: [{ type: Input }],
    mountParcel: [{ type: Input }],
    onParcelMount: [{ type: Input }],
    wrapWith: [{ type: Input }],
    customProps: [{ type: Input }],
    appendTo: [{ type: Input }],
    handleError: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFyY2VsLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIvVXNlcnMvam9lbGRlbm5pbmcvY29kZS9zaW5nbGUtc3BhLWFuZ3VsYXIvbGlicy9zaW5nbGUtc3BhLWFuZ3VsYXIvIiwic291cmNlcyI6WyJzcmMvcGFyY2VsLWxpYi9wYXJjZWwuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQXFCLEtBQUssRUFBYSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFPM0YsTUFBTSxPQUFPLGVBQWU7SUFlMUIsc0VBQXNFO0lBQ3RFLFlBQW9CLElBQTZCO1FBQTdCLFNBQUksR0FBSixJQUFJLENBQXlCO1FBYnhDLGtCQUFhLEdBQXdCLElBQUksQ0FBQztRQUMxQyxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ2pCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO1FBQ3pCLGFBQVEsR0FBZ0IsSUFBSSxDQUFDO1FBQzdCLGdCQUFXLEdBQUcsQ0FBQyxLQUFZLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFOUQsc0JBQWlCLEdBQXVCLElBQUksQ0FBQztRQUM3QyxhQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ2pCLGNBQVMsR0FBRyxJQUFJLENBQUM7SUFLbUMsQ0FBQztJQUVyRCxRQUFRO1FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsTUFBTSxJQUFJLEtBQUssQ0FDYixvTUFBb00sQ0FDck0sQ0FBQztTQUNIO1FBRUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFO1lBQzlCLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7WUFDckMsSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQzs7O0tBR25CLENBQUMsQ0FBQzthQUNBO1lBQ0QsSUFBSSxVQUF1QixDQUFDO1lBRTVCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDakIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDNUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDdkM7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDNUUsMkVBQTJFO2dCQUMzRSxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RELFNBQVMsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDbkM7WUFFRCxJQUFJLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxrQkFBSSxVQUFVLElBQUssSUFBSSxDQUFDLFdBQVcsRUFBRyxDQUFDO1lBRTVFLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtnQkFDdEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzthQUNuRDtZQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNULElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRTtZQUMvQixJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQ3JDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQzdDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNULElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLEdBQUcsRUFBRTtZQUNoQyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsS0FBSyxTQUFTLEVBQUU7Z0JBQ3hELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUM5QjtRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDMUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFVBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDeEU7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztJQUN4QixDQUFDO0lBRUQsWUFBWSxDQUFDLE1BQWMsRUFBRSxLQUFlO1FBQzFDLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxFQUFFO1lBQ3pDLHdFQUF3RTtZQUN4RSxPQUFPO1NBQ1I7UUFFRCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDM0QsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRTtZQUNoQixJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksTUFBTSxLQUFLLFNBQVMsRUFBRTtnQkFDMUMsd0RBQXdEO2dCQUN4RCxPQUFPO2FBQ1I7WUFFRCxPQUFPLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1FBQ3hCLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNiLElBQUksQ0FBQyxhQUFhLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsa0RBQWtEO1lBQzFGLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBRXJCLElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7Z0JBQzFCLEtBQUssQ0FBQyxPQUFPLEdBQUcsV0FBVyxNQUFNLDZCQUE2QixLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDL0U7WUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7Z0JBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDekI7aUJBQU07Z0JBQ0wsVUFBVSxDQUFDLEdBQUcsRUFBRTtvQkFDZCxNQUFNLEtBQUssQ0FBQztnQkFDZCxDQUFDLENBQUMsQ0FBQzthQUNKO1lBRUQseUVBQXlFO1lBQ3pFLE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDOzs7WUFuSEYsU0FBUyxTQUFDO2dCQUNULFFBQVEsRUFBRSxRQUFRO2dCQUNsQixRQUFRLEVBQUUsYUFBYTthQUN4Qjs7O1lBTndELFVBQVU7OztxQkFRaEUsS0FBSzswQkFDTCxLQUFLOzRCQUNMLEtBQUs7dUJBQ0wsS0FBSzswQkFDTCxLQUFLO3VCQUNMLEtBQUs7MEJBQ0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBPbkRlc3Ryb3ksIElucHV0LCBPbkNoYW5nZXMsIEVsZW1lbnRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFBhcmNlbCwgUGFyY2VsQ29uZmlnLCBBcHBQcm9wcyB9IGZyb20gJ3NpbmdsZS1zcGEnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdwYXJjZWwnLFxuICB0ZW1wbGF0ZTogJzxkaXY+PC9kaXY+Jyxcbn0pXG5leHBvcnQgY2xhc3MgUGFyY2VsQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3ksIE9uQ2hhbmdlcyB7XG4gIEBJbnB1dCgpIGNvbmZpZyE6IFBhcmNlbENvbmZpZztcbiAgQElucHV0KCkgbW91bnRQYXJjZWwhOiBBcHBQcm9wc1snbW91bnRQYXJjZWwnXTtcbiAgQElucHV0KCkgb25QYXJjZWxNb3VudDogKCgpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG4gIEBJbnB1dCgpIHdyYXBXaXRoID0gJ2Rpdic7XG4gIEBJbnB1dCgpIGN1c3RvbVByb3BzOiBvYmplY3QgPSB7fTtcbiAgQElucHV0KCkgYXBwZW5kVG86IE5vZGUgfCBudWxsID0gbnVsbDtcbiAgQElucHV0KCkgaGFuZGxlRXJyb3IgPSAoZXJyb3I6IEVycm9yKSA9PiBjb25zb2xlLmVycm9yKGVycm9yKTtcblxuICBjcmVhdGVkRG9tRWxlbWVudDogSFRNTEVsZW1lbnQgfCBudWxsID0gbnVsbDtcbiAgaGFzRXJyb3IgPSBmYWxzZTtcbiAgdW5tb3VudGVkID0gdHJ1ZTtcbiAgbmV4dFRoaW5nVG9EbyE6IFByb21pc2U8YW55PjtcbiAgcGFyY2VsITogUGFyY2VsO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tcGFyYW1ldGVyLXByb3BlcnRpZXNcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBob3N0OiBFbGVtZW50UmVmPEhUTUxFbGVtZW50Pikge31cblxuICBuZ09uSW5pdCgpIHtcbiAgICBpZiAoIXRoaXMuY29uZmlnKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBzaW5nbGUtc3BhLWFuZ3VsYXIncyBQYXJjZWwgY29tcG9uZW50IHJlcXVpcmVzIHRoZSBbY29uZmlnXSBiaW5kaW5nIHRvIGVpdGhlciBiZSBhIHBhcmNlbCBjb25maWcgb3IgYSBsb2FkaW5nIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIHByb21pc2UuIFNlZSBodHRwczovL2dpdGh1Yi5jb20vQ2Fub3B5VGF4L3NpbmdsZS1zcGEtYW5ndWxhcmAsXG4gICAgICApO1xuICAgIH1cblxuICAgIHRoaXMuYWRkVGhpbmdUb0RvKCdtb3VudCcsICgpID0+IHtcbiAgICAgIGNvbnN0IG1vdW50UGFyY2VsID0gdGhpcy5tb3VudFBhcmNlbDtcbiAgICAgIGlmICghbW91bnRQYXJjZWwpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBcblx0XHRcdFx0ICA8cGFyY2VsPiB3YXMgbm90IHBhc3NlZCBhIFttb3VudFBhcmNlbF0gYmluZGluZy5cblx0XHRcdFx0ICBJZiB5b3UgYXJlIHVzaW5nIDxwYXJjZWw+IHdpdGhpbiBhIG1vZHVsZSB0aGF0IGlzIG5vdCBhIHNpbmdsZS1zcGEgYXBwbGljYXRpb24sIHlvdSB3aWxsIG5lZWQgdG8gaW1wb3J0IG1vdW50Um9vdFBhcmNlbCBmcm9tIHNpbmdsZS1zcGEgYW5kIHBhc3MgaXQgaW50byA8cGFyY2VsPiBhcyBhIFttb3VudFBhcmNlbF0gYmluZGluZ1xuXHRcdFx0XHRgKTtcbiAgICAgIH1cbiAgICAgIGxldCBkb21FbGVtZW50OiBIVE1MRWxlbWVudDtcblxuICAgICAgaWYgKHRoaXMuYXBwZW5kVG8pIHtcbiAgICAgICAgdGhpcy5jcmVhdGVkRG9tRWxlbWVudCA9IGRvbUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRoaXMud3JhcFdpdGgpO1xuICAgICAgICB0aGlzLmFwcGVuZFRvLmFwcGVuZENoaWxkKGRvbUVsZW1lbnQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5jcmVhdGVkRG9tRWxlbWVudCA9IGRvbUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KHRoaXMud3JhcFdpdGgpO1xuICAgICAgICAvLyBFeGNlcHQgb2YgaGF2aW5nIGBAVmlld0NoaWxkYCB3ZSBjYW4gc2ltcGx5IGdldCB0aGUgZmlyc3QgY2hpbGQgZWxlbWVudC5cbiAgICAgICAgY29uc3QgcGFyY2VsRGl2ID0gdGhpcy5ob3N0Lm5hdGl2ZUVsZW1lbnQuY2hpbGRyZW5bMF07XG4gICAgICAgIHBhcmNlbERpdi5hcHBlbmRDaGlsZChkb21FbGVtZW50KTtcbiAgICAgIH1cblxuICAgICAgdGhpcy5wYXJjZWwgPSBtb3VudFBhcmNlbCh0aGlzLmNvbmZpZywgeyBkb21FbGVtZW50LCAuLi50aGlzLmN1c3RvbVByb3BzIH0pO1xuXG4gICAgICBpZiAodGhpcy5vblBhcmNlbE1vdW50KSB7XG4gICAgICAgIHRoaXMucGFyY2VsLm1vdW50UHJvbWlzZS50aGVuKHRoaXMub25QYXJjZWxNb3VudCk7XG4gICAgICB9XG4gICAgICB0aGlzLnVubW91bnRlZCA9IGZhbHNlO1xuICAgICAgcmV0dXJuIHRoaXMucGFyY2VsLm1vdW50UHJvbWlzZTtcbiAgICB9KTtcbiAgfVxuXG4gIG5nT25DaGFuZ2VzKCkge1xuICAgIHRoaXMuYWRkVGhpbmdUb0RvKCd1cGRhdGUnLCAoKSA9PiB7XG4gICAgICBpZiAodGhpcy5wYXJjZWwgJiYgdGhpcy5wYXJjZWwudXBkYXRlKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhcmNlbC51cGRhdGUodGhpcy5jdXN0b21Qcm9wcyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLmFkZFRoaW5nVG9EbygndW5tb3VudCcsICgpID0+IHtcbiAgICAgIGlmICh0aGlzLnBhcmNlbCAmJiB0aGlzLnBhcmNlbC5nZXRTdGF0dXMoKSA9PT0gJ01PVU5URUQnKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhcmNlbC51bm1vdW50KCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5jcmVhdGVkRG9tRWxlbWVudCkge1xuICAgICAgdGhpcy5jcmVhdGVkRG9tRWxlbWVudC5wYXJlbnROb2RlIS5yZW1vdmVDaGlsZCh0aGlzLmNyZWF0ZWREb21FbGVtZW50KTtcbiAgICB9XG5cbiAgICB0aGlzLnVubW91bnRlZCA9IHRydWU7XG4gIH1cblxuICBhZGRUaGluZ1RvRG8oYWN0aW9uOiBzdHJpbmcsIHRoaW5nOiBGdW5jdGlvbikge1xuICAgIGlmICh0aGlzLmhhc0Vycm9yICYmIGFjdGlvbiAhPT0gJ3VubW91bnQnKSB7XG4gICAgICAvLyBJbiBhbiBlcnJvciBzdGF0ZSwgd2UgZG9uJ3QgZG8gYW55dGhpbmcgYW55bW9yZSBleGNlcHQgZm9yIHVubW91bnRpbmdcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLm5leHRUaGluZ1RvRG8gPSAodGhpcy5uZXh0VGhpbmdUb0RvIHx8IFByb21pc2UucmVzb2x2ZSgpKVxuICAgICAgLnRoZW4oKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgaWYgKHRoaXMudW5tb3VudGVkICYmIGFjdGlvbiAhPT0gJ3VubW91bnQnKSB7XG4gICAgICAgICAgLy8gTmV2ZXIgZG8gYW55dGhpbmcgb25jZSB0aGUgYW5ndWxhciBjb21wb25lbnQgdW5tb3VudHNcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpbmcoLi4uYXJncyk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKGVycm9yID0+IHtcbiAgICAgICAgdGhpcy5uZXh0VGhpbmdUb0RvID0gUHJvbWlzZS5yZXNvbHZlKCk7IC8vIHJlc2V0IHNvIHdlIGRvbid0IC50aGVuKCkgdGhlIGJhZCBwcm9taXNlIGFnYWluXG4gICAgICAgIHRoaXMuaGFzRXJyb3IgPSB0cnVlO1xuXG4gICAgICAgIGlmIChlcnJvciAmJiBlcnJvci5tZXNzYWdlKSB7XG4gICAgICAgICAgZXJyb3IubWVzc2FnZSA9IGBEdXJpbmcgJyR7YWN0aW9ufScsIHBhcmNlbCB0aHJldyBhbiBlcnJvcjogJHtlcnJvci5tZXNzYWdlfWA7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaGFuZGxlRXJyb3IgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZUVycm9yKGVycm9yKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gTm8gbW9yZSB0aGluZ3MgdG8gZG8gc2hvdWxkIGJlIGRvbmUgLS0gdGhlIHBhcmNlbCBpcyBpbiBhbiBlcnJvciBzdGF0ZVxuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH0pO1xuICB9XG59XG4iXX0=