import { NgModule } from '@angular/core';
import { ParcelComponent } from './parcel.component';
export class ParcelModule {
}
ParcelModule.decorators = [
    { type: NgModule, args: [{
                declarations: [ParcelComponent],
                exports: [ParcelComponent],
                entryComponents: [ParcelComponent],
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiL1VzZXJzL2pvZWxkZW5uaW5nL2NvZGUvc2luZ2xlLXNwYS1hbmd1bGFyL2xpYnMvc2luZ2xlLXNwYS1hbmd1bGFyLyIsInNvdXJjZXMiOlsic3JjL3BhcmNlbC1saWIvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFPckQsTUFBTSxPQUFPLFlBQVk7OztZQUx4QixRQUFRLFNBQUM7Z0JBQ1IsWUFBWSxFQUFFLENBQUMsZUFBZSxDQUFDO2dCQUMvQixPQUFPLEVBQUUsQ0FBQyxlQUFlLENBQUM7Z0JBQzFCLGVBQWUsRUFBRSxDQUFDLGVBQWUsQ0FBQzthQUNuQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBQYXJjZWxDb21wb25lbnQgfSBmcm9tICcuL3BhcmNlbC5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtQYXJjZWxDb21wb25lbnRdLFxuICBleHBvcnRzOiBbUGFyY2VsQ29tcG9uZW50XSxcbiAgZW50cnlDb21wb25lbnRzOiBbUGFyY2VsQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgUGFyY2VsTW9kdWxlIHt9XG4iXX0=