import { Injectable, Inject } from '@angular/core';
import { ɵBrowserPlatformLocation, PlatformLocation, DOCUMENT, } from '@angular/common';
export class SingleSpaPlatformLocation extends ɵBrowserPlatformLocation {
    constructor() {
        super(...arguments);
        // This is a simple marker that helps us to ignore PopStateEvents
        // that was not dispatched by the browser.
        this.skipNextPopState = false;
        // The key here is an actual forked `Zone` of some specific application.
        // We will be able to find the specific zone when application gets destroyed
        // by application `name`.
        // The reason of that the `onPopState` method is invoked during `bootstrapModule`
        // and we can't know what application has invoked it. Why should we know the application
        // that has invoked `onPopState`? When application gets destroyed in a `sharing dependencies mode`
        // (when there is a single platform per all applications) we want to remove application
        // specific `popstate` listeners. E.g. if there are 2 applications:
        // * shop application adds `popstate` listener
        // * navbar application adds `popstate` listener
        // When shop application gets destroyed we want to remove only its `popstate` listener.
        this.zoneToOnPopStateListenersMap = new Map();
        // This is used only to make `Zone.wrap` happy, since it requires 2 arguments
        // and the second argument is a unique string which `zone.js` uses for debugging purposes.
        // We might want to use the application name, but we're not able to get it when `onPopState`
        // method is called during module bootstrapping.
        this.source = 0;
    }
    destroyApplication(zoneIdentifier) {
        // TLDR: Angular adds `popstate` event listener and then doesn't remove it when application gets destroyed.
        // Basically, Angular has a potentional memory leak. The `ɵBrowserPlatformLocation`
        // has `onPopState` method which adds `popstate` event listener and forgets, see here:
        // https://github.com/angular/angular/blob/14be55c9facf3e47b8c97df4502dc3f0f897da03/packages/common/src/location/platform_location.ts#L126
        const zone = [...this.zoneToOnPopStateListenersMap.keys()].find(
        // `getZoneWith` will return a zone which defines a `key` and in our case
        // we define a custom key in `single-spa-angular.ts`
        // via this line of code:
        // `_properties[zoneIdentifier] = true;`
        zone => zone.getZoneWith(zoneIdentifier) !== null);
        const onPopStateListeners = this.zoneToOnPopStateListenersMap.get(zone);
        if (Array.isArray(onPopStateListeners)) {
            for (const onPopStateListener of onPopStateListeners) {
                window.removeEventListener('popstate', onPopStateListener);
            }
        }
        this.zoneToOnPopStateListenersMap.delete(zone);
    }
    pushState(state, title, url) {
        this.skipNextPopState = true;
        super.pushState(state, title, url);
    }
    replaceState(state, title, url) {
        this.skipNextPopState = true;
        super.replaceState(state, title, url);
    }
    onPopState(fn) {
        // `Zone.current` will reference the zone that serves as an execution context
        // to some specific application, especially when `onPopState` is called.
        const zone = Zone.current;
        // Wrap any event listener into zone that is specific to some application.
        // The main issue is `back/forward` buttons of browsers, because they invoke
        // `history.back|forward` which dispatch `popstate` event. Since `single-spa`
        // overrides `history.replaceState` Angular's zone cannot intercept this event.
        // Only the root zone is able to intercept all events.
        // See https://github.com/single-spa/single-spa-angular/issues/94 for more details
        fn = zone.wrap(fn, `${this.source++}`);
        const onPopStateListener = (event) => {
            // The `LocationChangeEvent` doesn't have the `singleSpa` property, since it's added
            // by `single-spa` starting from `5.4` version. We need this check because we want
            // to skip "unnatural" PopStateEvents, the one caused by `single-spa`.
            const popStateEventWasDispatchedBySingleSpa = !!event
                .singleSpa;
            if (this.skipNextPopState && popStateEventWasDispatchedBySingleSpa) {
                this.skipNextPopState = false;
            }
            else {
                fn(event);
            }
        };
        this.storeOnPopStateListener(zone, onPopStateListener);
        super.onPopState(onPopStateListener);
    }
    storeOnPopStateListener(zone, onPopStateListener) {
        // All listeners should be stored inside an array because the `onPopState` can be called
        // multiple times thus we wanna reference all listeners to remove them further.
        const onPopStateListeners = this.zoneToOnPopStateListenersMap.get(zone) || [];
        onPopStateListeners.push(onPopStateListener);
        if (!this.zoneToOnPopStateListenersMap.has(zone)) {
            this.zoneToOnPopStateListenersMap.set(zone, onPopStateListeners);
        }
    }
}
SingleSpaPlatformLocation.decorators = [
    { type: Injectable }
];
/**
 * The `PlatformLocation` class is an "injectee" of the `PathLocationStrategy`,
 * which creates `Subject` internally for listening on `popstate` events. We want
 * to provide this class in the most top injector that's used during bootstrapping.
 */
export function getSingleSpaExtraProviders() {
    return [
        {
            provide: SingleSpaPlatformLocation,
            useClass: SingleSpaPlatformLocation,
            deps: [[new Inject(DOCUMENT)]],
        },
        {
            provide: PlatformLocation,
            useExisting: SingleSpaPlatformLocation,
        },
    ];
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXh0cmEtcHJvdmlkZXJzLmpzIiwic291cmNlUm9vdCI6Ii9Vc2Vycy9qb2VsZGVubmluZy9jb2RlL3NpbmdsZS1zcGEtYW5ndWxhci9saWJzL3NpbmdsZS1zcGEtYW5ndWxhci8iLCJzb3VyY2VzIjpbInNyYy9leHRyYS1wcm92aWRlcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBa0IsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25FLE9BQU8sRUFDTCx3QkFBd0IsRUFDeEIsZ0JBQWdCLEVBRWhCLFFBQVEsR0FDVCxNQUFNLGlCQUFpQixDQUFDO0FBT3pCLE1BQU0sT0FBTyx5QkFBMEIsU0FBUSx3QkFBd0I7SUFEdkU7O1FBRUUsaUVBQWlFO1FBQ2pFLDBDQUEwQztRQUNsQyxxQkFBZ0IsR0FBRyxLQUFLLENBQUM7UUFFakMsd0VBQXdFO1FBQ3hFLDRFQUE0RTtRQUM1RSx5QkFBeUI7UUFDekIsaUZBQWlGO1FBQ2pGLHdGQUF3RjtRQUN4RixrR0FBa0c7UUFDbEcsdUZBQXVGO1FBQ3ZGLG1FQUFtRTtRQUNuRSw4Q0FBOEM7UUFDOUMsZ0RBQWdEO1FBQ2hELHVGQUF1RjtRQUMvRSxpQ0FBNEIsR0FBRyxJQUFJLEdBQUcsRUFBNkIsQ0FBQztRQUU1RSw2RUFBNkU7UUFDN0UsMEZBQTBGO1FBQzFGLDRGQUE0RjtRQUM1RixnREFBZ0Q7UUFDeEMsV0FBTSxHQUFHLENBQUMsQ0FBQztJQWlGckIsQ0FBQztJQS9FQyxrQkFBa0IsQ0FBQyxjQUFzQjtRQUN2QywyR0FBMkc7UUFDM0csbUZBQW1GO1FBQ25GLHNGQUFzRjtRQUN0RiwwSUFBMEk7UUFDMUksTUFBTSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7UUFDN0QseUVBQXlFO1FBQ3pFLG9EQUFvRDtRQUNwRCx5QkFBeUI7UUFDekIsd0NBQXdDO1FBQ3hDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsS0FBSyxJQUFJLENBQ2xELENBQUM7UUFFRixNQUFNLG1CQUFtQixHQUVULElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFNUQsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLEVBQUU7WUFDdEMsS0FBSyxNQUFNLGtCQUFrQixJQUFJLG1CQUFtQixFQUFFO2dCQUNwRCxNQUFNLENBQUMsbUJBQW1CLENBQUMsVUFBVSxFQUFFLGtCQUFrQixDQUFDLENBQUM7YUFDNUQ7U0FDRjtRQUVELElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVELFNBQVMsQ0FBQyxLQUFVLEVBQUUsS0FBYSxFQUFFLEdBQVc7UUFDOUMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUM3QixLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFVLEVBQUUsS0FBYSxFQUFFLEdBQVc7UUFDakQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUM3QixLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxFQUFzQjtRQUMvQiw2RUFBNkU7UUFDN0Usd0VBQXdFO1FBQ3hFLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7UUFFMUIsMEVBQTBFO1FBQzFFLDRFQUE0RTtRQUM1RSw2RUFBNkU7UUFDN0UsK0VBQStFO1FBQy9FLHNEQUFzRDtRQUN0RCxrRkFBa0Y7UUFDbEYsRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztRQUV2QyxNQUFNLGtCQUFrQixHQUFHLENBQUMsS0FBMEIsRUFBRSxFQUFFO1lBQ3hELG9GQUFvRjtZQUNwRixrRkFBa0Y7WUFDbEYsc0VBQXNFO1lBQ3RFLE1BQU0scUNBQXFDLEdBQUcsQ0FBQyxDQUFHLEtBQTRDO2lCQUMzRixTQUFTLENBQUM7WUFFYixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxxQ0FBcUMsRUFBRTtnQkFDbEUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQzthQUMvQjtpQkFBTTtnQkFDTCxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDWDtRQUNILENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztRQUN2RCxLQUFLLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVPLHVCQUF1QixDQUFDLElBQVMsRUFBRSxrQkFBc0M7UUFDL0Usd0ZBQXdGO1FBQ3hGLCtFQUErRTtRQUMvRSxNQUFNLG1CQUFtQixHQUN2QixJQUFJLENBQUMsNEJBQTRCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUVwRCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUU3QyxJQUFJLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoRCxJQUFJLENBQUMsNEJBQTRCLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1NBQ2xFO0lBQ0gsQ0FBQzs7O1lBdkdGLFVBQVU7O0FBMEdYOzs7O0dBSUc7QUFDSCxNQUFNLFVBQVUsMEJBQTBCO0lBQ3hDLE9BQU87UUFDTDtZQUNFLE9BQU8sRUFBRSx5QkFBeUI7WUFDbEMsUUFBUSxFQUFFLHlCQUF5QjtZQUNuQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDL0I7UUFDRDtZQUNFLE9BQU8sRUFBRSxnQkFBZ0I7WUFDekIsV0FBVyxFQUFFLHlCQUF5QjtTQUN2QztLQUNGLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgU3RhdGljUHJvdmlkZXIsIEluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgybVCcm93c2VyUGxhdGZvcm1Mb2NhdGlvbixcbiAgUGxhdGZvcm1Mb2NhdGlvbixcbiAgTG9jYXRpb25DaGFuZ2VFdmVudCxcbiAgRE9DVU1FTlQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5cbnR5cGUgT25Qb3BTdGF0ZUxpc3RlbmVyID0gKGV2ZW50OiBMb2NhdGlvbkNoYW5nZUV2ZW50KSA9PiB2b2lkO1xuXG5kZWNsYXJlIGNvbnN0IFpvbmU6IGFueTtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIFNpbmdsZVNwYVBsYXRmb3JtTG9jYXRpb24gZXh0ZW5kcyDJtUJyb3dzZXJQbGF0Zm9ybUxvY2F0aW9uIHtcbiAgLy8gVGhpcyBpcyBhIHNpbXBsZSBtYXJrZXIgdGhhdCBoZWxwcyB1cyB0byBpZ25vcmUgUG9wU3RhdGVFdmVudHNcbiAgLy8gdGhhdCB3YXMgbm90IGRpc3BhdGNoZWQgYnkgdGhlIGJyb3dzZXIuXG4gIHByaXZhdGUgc2tpcE5leHRQb3BTdGF0ZSA9IGZhbHNlO1xuXG4gIC8vIFRoZSBrZXkgaGVyZSBpcyBhbiBhY3R1YWwgZm9ya2VkIGBab25lYCBvZiBzb21lIHNwZWNpZmljIGFwcGxpY2F0aW9uLlxuICAvLyBXZSB3aWxsIGJlIGFibGUgdG8gZmluZCB0aGUgc3BlY2lmaWMgem9uZSB3aGVuIGFwcGxpY2F0aW9uIGdldHMgZGVzdHJveWVkXG4gIC8vIGJ5IGFwcGxpY2F0aW9uIGBuYW1lYC5cbiAgLy8gVGhlIHJlYXNvbiBvZiB0aGF0IHRoZSBgb25Qb3BTdGF0ZWAgbWV0aG9kIGlzIGludm9rZWQgZHVyaW5nIGBib290c3RyYXBNb2R1bGVgXG4gIC8vIGFuZCB3ZSBjYW4ndCBrbm93IHdoYXQgYXBwbGljYXRpb24gaGFzIGludm9rZWQgaXQuIFdoeSBzaG91bGQgd2Uga25vdyB0aGUgYXBwbGljYXRpb25cbiAgLy8gdGhhdCBoYXMgaW52b2tlZCBgb25Qb3BTdGF0ZWA/IFdoZW4gYXBwbGljYXRpb24gZ2V0cyBkZXN0cm95ZWQgaW4gYSBgc2hhcmluZyBkZXBlbmRlbmNpZXMgbW9kZWBcbiAgLy8gKHdoZW4gdGhlcmUgaXMgYSBzaW5nbGUgcGxhdGZvcm0gcGVyIGFsbCBhcHBsaWNhdGlvbnMpIHdlIHdhbnQgdG8gcmVtb3ZlIGFwcGxpY2F0aW9uXG4gIC8vIHNwZWNpZmljIGBwb3BzdGF0ZWAgbGlzdGVuZXJzLiBFLmcuIGlmIHRoZXJlIGFyZSAyIGFwcGxpY2F0aW9uczpcbiAgLy8gKiBzaG9wIGFwcGxpY2F0aW9uIGFkZHMgYHBvcHN0YXRlYCBsaXN0ZW5lclxuICAvLyAqIG5hdmJhciBhcHBsaWNhdGlvbiBhZGRzIGBwb3BzdGF0ZWAgbGlzdGVuZXJcbiAgLy8gV2hlbiBzaG9wIGFwcGxpY2F0aW9uIGdldHMgZGVzdHJveWVkIHdlIHdhbnQgdG8gcmVtb3ZlIG9ubHkgaXRzIGBwb3BzdGF0ZWAgbGlzdGVuZXIuXG4gIHByaXZhdGUgem9uZVRvT25Qb3BTdGF0ZUxpc3RlbmVyc01hcCA9IG5ldyBNYXA8YW55LCBPblBvcFN0YXRlTGlzdGVuZXJbXT4oKTtcblxuICAvLyBUaGlzIGlzIHVzZWQgb25seSB0byBtYWtlIGBab25lLndyYXBgIGhhcHB5LCBzaW5jZSBpdCByZXF1aXJlcyAyIGFyZ3VtZW50c1xuICAvLyBhbmQgdGhlIHNlY29uZCBhcmd1bWVudCBpcyBhIHVuaXF1ZSBzdHJpbmcgd2hpY2ggYHpvbmUuanNgIHVzZXMgZm9yIGRlYnVnZ2luZyBwdXJwb3Nlcy5cbiAgLy8gV2UgbWlnaHQgd2FudCB0byB1c2UgdGhlIGFwcGxpY2F0aW9uIG5hbWUsIGJ1dCB3ZSdyZSBub3QgYWJsZSB0byBnZXQgaXQgd2hlbiBgb25Qb3BTdGF0ZWBcbiAgLy8gbWV0aG9kIGlzIGNhbGxlZCBkdXJpbmcgbW9kdWxlIGJvb3RzdHJhcHBpbmcuXG4gIHByaXZhdGUgc291cmNlID0gMDtcblxuICBkZXN0cm95QXBwbGljYXRpb24oem9uZUlkZW50aWZpZXI6IHN0cmluZyk6IHZvaWQge1xuICAgIC8vIFRMRFI6IEFuZ3VsYXIgYWRkcyBgcG9wc3RhdGVgIGV2ZW50IGxpc3RlbmVyIGFuZCB0aGVuIGRvZXNuJ3QgcmVtb3ZlIGl0IHdoZW4gYXBwbGljYXRpb24gZ2V0cyBkZXN0cm95ZWQuXG4gICAgLy8gQmFzaWNhbGx5LCBBbmd1bGFyIGhhcyBhIHBvdGVudGlvbmFsIG1lbW9yeSBsZWFrLiBUaGUgYMm1QnJvd3NlclBsYXRmb3JtTG9jYXRpb25gXG4gICAgLy8gaGFzIGBvblBvcFN0YXRlYCBtZXRob2Qgd2hpY2ggYWRkcyBgcG9wc3RhdGVgIGV2ZW50IGxpc3RlbmVyIGFuZCBmb3JnZXRzLCBzZWUgaGVyZTpcbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2Jsb2IvMTRiZTU1YzlmYWNmM2U0N2I4Yzk3ZGY0NTAyZGMzZjBmODk3ZGEwMy9wYWNrYWdlcy9jb21tb24vc3JjL2xvY2F0aW9uL3BsYXRmb3JtX2xvY2F0aW9uLnRzI0wxMjZcbiAgICBjb25zdCB6b25lID0gWy4uLnRoaXMuem9uZVRvT25Qb3BTdGF0ZUxpc3RlbmVyc01hcC5rZXlzKCldLmZpbmQoXG4gICAgICAvLyBgZ2V0Wm9uZVdpdGhgIHdpbGwgcmV0dXJuIGEgem9uZSB3aGljaCBkZWZpbmVzIGEgYGtleWAgYW5kIGluIG91ciBjYXNlXG4gICAgICAvLyB3ZSBkZWZpbmUgYSBjdXN0b20ga2V5IGluIGBzaW5nbGUtc3BhLWFuZ3VsYXIudHNgXG4gICAgICAvLyB2aWEgdGhpcyBsaW5lIG9mIGNvZGU6XG4gICAgICAvLyBgX3Byb3BlcnRpZXNbem9uZUlkZW50aWZpZXJdID0gdHJ1ZTtgXG4gICAgICB6b25lID0+IHpvbmUuZ2V0Wm9uZVdpdGgoem9uZUlkZW50aWZpZXIpICE9PSBudWxsLFxuICAgICk7XG5cbiAgICBjb25zdCBvblBvcFN0YXRlTGlzdGVuZXJzOlxuICAgICAgfCBPblBvcFN0YXRlTGlzdGVuZXJbXVxuICAgICAgfCB1bmRlZmluZWQgPSB0aGlzLnpvbmVUb09uUG9wU3RhdGVMaXN0ZW5lcnNNYXAuZ2V0KHpvbmUpO1xuXG4gICAgaWYgKEFycmF5LmlzQXJyYXkob25Qb3BTdGF0ZUxpc3RlbmVycykpIHtcbiAgICAgIGZvciAoY29uc3Qgb25Qb3BTdGF0ZUxpc3RlbmVyIG9mIG9uUG9wU3RhdGVMaXN0ZW5lcnMpIHtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3BvcHN0YXRlJywgb25Qb3BTdGF0ZUxpc3RlbmVyKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLnpvbmVUb09uUG9wU3RhdGVMaXN0ZW5lcnNNYXAuZGVsZXRlKHpvbmUpO1xuICB9XG5cbiAgcHVzaFN0YXRlKHN0YXRlOiBhbnksIHRpdGxlOiBzdHJpbmcsIHVybDogc3RyaW5nKTogdm9pZCB7XG4gICAgdGhpcy5za2lwTmV4dFBvcFN0YXRlID0gdHJ1ZTtcbiAgICBzdXBlci5wdXNoU3RhdGUoc3RhdGUsIHRpdGxlLCB1cmwpO1xuICB9XG5cbiAgcmVwbGFjZVN0YXRlKHN0YXRlOiBhbnksIHRpdGxlOiBzdHJpbmcsIHVybDogc3RyaW5nKTogdm9pZCB7XG4gICAgdGhpcy5za2lwTmV4dFBvcFN0YXRlID0gdHJ1ZTtcbiAgICBzdXBlci5yZXBsYWNlU3RhdGUoc3RhdGUsIHRpdGxlLCB1cmwpO1xuICB9XG5cbiAgb25Qb3BTdGF0ZShmbjogT25Qb3BTdGF0ZUxpc3RlbmVyKTogdm9pZCB7XG4gICAgLy8gYFpvbmUuY3VycmVudGAgd2lsbCByZWZlcmVuY2UgdGhlIHpvbmUgdGhhdCBzZXJ2ZXMgYXMgYW4gZXhlY3V0aW9uIGNvbnRleHRcbiAgICAvLyB0byBzb21lIHNwZWNpZmljIGFwcGxpY2F0aW9uLCBlc3BlY2lhbGx5IHdoZW4gYG9uUG9wU3RhdGVgIGlzIGNhbGxlZC5cbiAgICBjb25zdCB6b25lID0gWm9uZS5jdXJyZW50O1xuXG4gICAgLy8gV3JhcCBhbnkgZXZlbnQgbGlzdGVuZXIgaW50byB6b25lIHRoYXQgaXMgc3BlY2lmaWMgdG8gc29tZSBhcHBsaWNhdGlvbi5cbiAgICAvLyBUaGUgbWFpbiBpc3N1ZSBpcyBgYmFjay9mb3J3YXJkYCBidXR0b25zIG9mIGJyb3dzZXJzLCBiZWNhdXNlIHRoZXkgaW52b2tlXG4gICAgLy8gYGhpc3RvcnkuYmFja3xmb3J3YXJkYCB3aGljaCBkaXNwYXRjaCBgcG9wc3RhdGVgIGV2ZW50LiBTaW5jZSBgc2luZ2xlLXNwYWBcbiAgICAvLyBvdmVycmlkZXMgYGhpc3RvcnkucmVwbGFjZVN0YXRlYCBBbmd1bGFyJ3Mgem9uZSBjYW5ub3QgaW50ZXJjZXB0IHRoaXMgZXZlbnQuXG4gICAgLy8gT25seSB0aGUgcm9vdCB6b25lIGlzIGFibGUgdG8gaW50ZXJjZXB0IGFsbCBldmVudHMuXG4gICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9zaW5nbGUtc3BhL3NpbmdsZS1zcGEtYW5ndWxhci9pc3N1ZXMvOTQgZm9yIG1vcmUgZGV0YWlsc1xuICAgIGZuID0gem9uZS53cmFwKGZuLCBgJHt0aGlzLnNvdXJjZSsrfWApO1xuXG4gICAgY29uc3Qgb25Qb3BTdGF0ZUxpc3RlbmVyID0gKGV2ZW50OiBMb2NhdGlvbkNoYW5nZUV2ZW50KSA9PiB7XG4gICAgICAvLyBUaGUgYExvY2F0aW9uQ2hhbmdlRXZlbnRgIGRvZXNuJ3QgaGF2ZSB0aGUgYHNpbmdsZVNwYWAgcHJvcGVydHksIHNpbmNlIGl0J3MgYWRkZWRcbiAgICAgIC8vIGJ5IGBzaW5nbGUtc3BhYCBzdGFydGluZyBmcm9tIGA1LjRgIHZlcnNpb24uIFdlIG5lZWQgdGhpcyBjaGVjayBiZWNhdXNlIHdlIHdhbnRcbiAgICAgIC8vIHRvIHNraXAgXCJ1bm5hdHVyYWxcIiBQb3BTdGF0ZUV2ZW50cywgdGhlIG9uZSBjYXVzZWQgYnkgYHNpbmdsZS1zcGFgLlxuICAgICAgY29uc3QgcG9wU3RhdGVFdmVudFdhc0Rpc3BhdGNoZWRCeVNpbmdsZVNwYSA9ICEhKChldmVudCBhcyB1bmtub3duKSBhcyB7IHNpbmdsZVNwYTogYm9vbGVhbiB9KVxuICAgICAgICAuc2luZ2xlU3BhO1xuXG4gICAgICBpZiAodGhpcy5za2lwTmV4dFBvcFN0YXRlICYmIHBvcFN0YXRlRXZlbnRXYXNEaXNwYXRjaGVkQnlTaW5nbGVTcGEpIHtcbiAgICAgICAgdGhpcy5za2lwTmV4dFBvcFN0YXRlID0gZmFsc2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmbihldmVudCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHRoaXMuc3RvcmVPblBvcFN0YXRlTGlzdGVuZXIoem9uZSwgb25Qb3BTdGF0ZUxpc3RlbmVyKTtcbiAgICBzdXBlci5vblBvcFN0YXRlKG9uUG9wU3RhdGVMaXN0ZW5lcik7XG4gIH1cblxuICBwcml2YXRlIHN0b3JlT25Qb3BTdGF0ZUxpc3RlbmVyKHpvbmU6IGFueSwgb25Qb3BTdGF0ZUxpc3RlbmVyOiBPblBvcFN0YXRlTGlzdGVuZXIpOiB2b2lkIHtcbiAgICAvLyBBbGwgbGlzdGVuZXJzIHNob3VsZCBiZSBzdG9yZWQgaW5zaWRlIGFuIGFycmF5IGJlY2F1c2UgdGhlIGBvblBvcFN0YXRlYCBjYW4gYmUgY2FsbGVkXG4gICAgLy8gbXVsdGlwbGUgdGltZXMgdGh1cyB3ZSB3YW5uYSByZWZlcmVuY2UgYWxsIGxpc3RlbmVycyB0byByZW1vdmUgdGhlbSBmdXJ0aGVyLlxuICAgIGNvbnN0IG9uUG9wU3RhdGVMaXN0ZW5lcnM6IE9uUG9wU3RhdGVMaXN0ZW5lcltdID1cbiAgICAgIHRoaXMuem9uZVRvT25Qb3BTdGF0ZUxpc3RlbmVyc01hcC5nZXQoem9uZSkgfHwgW107XG5cbiAgICBvblBvcFN0YXRlTGlzdGVuZXJzLnB1c2gob25Qb3BTdGF0ZUxpc3RlbmVyKTtcblxuICAgIGlmICghdGhpcy56b25lVG9PblBvcFN0YXRlTGlzdGVuZXJzTWFwLmhhcyh6b25lKSkge1xuICAgICAgdGhpcy56b25lVG9PblBvcFN0YXRlTGlzdGVuZXJzTWFwLnNldCh6b25lLCBvblBvcFN0YXRlTGlzdGVuZXJzKTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBUaGUgYFBsYXRmb3JtTG9jYXRpb25gIGNsYXNzIGlzIGFuIFwiaW5qZWN0ZWVcIiBvZiB0aGUgYFBhdGhMb2NhdGlvblN0cmF0ZWd5YCxcbiAqIHdoaWNoIGNyZWF0ZXMgYFN1YmplY3RgIGludGVybmFsbHkgZm9yIGxpc3RlbmluZyBvbiBgcG9wc3RhdGVgIGV2ZW50cy4gV2Ugd2FudFxuICogdG8gcHJvdmlkZSB0aGlzIGNsYXNzIGluIHRoZSBtb3N0IHRvcCBpbmplY3RvciB0aGF0J3MgdXNlZCBkdXJpbmcgYm9vdHN0cmFwcGluZy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNpbmdsZVNwYUV4dHJhUHJvdmlkZXJzKCk6IFN0YXRpY1Byb3ZpZGVyW10ge1xuICByZXR1cm4gW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IFNpbmdsZVNwYVBsYXRmb3JtTG9jYXRpb24sXG4gICAgICB1c2VDbGFzczogU2luZ2xlU3BhUGxhdGZvcm1Mb2NhdGlvbixcbiAgICAgIGRlcHM6IFtbbmV3IEluamVjdChET0NVTUVOVCldXSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHByb3ZpZGU6IFBsYXRmb3JtTG9jYXRpb24sXG4gICAgICB1c2VFeGlzdGluZzogU2luZ2xlU3BhUGxhdGZvcm1Mb2NhdGlvbixcbiAgICB9LFxuICBdO1xufVxuIl19