import { __awaiter } from 'tslib';
import { getContainerElementAndSetTemplate, removeApplicationFromDOMIfIvyEnabled } from 'single-spa-angular/internals';
import { Injectable, Inject, Component, ElementRef, Input, NgModule } from '@angular/core';
import { ɵBrowserPlatformLocation, DOCUMENT, PlatformLocation } from '@angular/common';

import * as ɵngcc0 from '@angular/core';
class SingleSpaPlatformLocation extends ɵBrowserPlatformLocation {
    constructor() {
        super(...arguments);
        // This is a simple marker that helps us to ignore PopStateEvents
        // that was not dispatched by the browser.
        this.skipNextPopState = false;
        // The key here is an actual forked `Zone` of some specific application.
        // We will be able to find the specific zone when application gets destroyed
        // by application `name`.
        // The reason of that the `onPopState` method is invoked during `bootstrapModule`
        // and we can't know what application has invoked it. Why should we know the application
        // that has invoked `onPopState`? When application gets destroyed in a `sharing dependencies mode`
        // (when there is a single platform per all applications) we want to remove application
        // specific `popstate` listeners. E.g. if there are 2 applications:
        // * shop application adds `popstate` listener
        // * navbar application adds `popstate` listener
        // When shop application gets destroyed we want to remove only its `popstate` listener.
        this.zoneToOnPopStateListenersMap = new Map();
        // This is used only to make `Zone.wrap` happy, since it requires 2 arguments
        // and the second argument is a unique string which `zone.js` uses for debugging purposes.
        // We might want to use the application name, but we're not able to get it when `onPopState`
        // method is called during module bootstrapping.
        this.source = 0;
    }
    destroyApplication(zoneIdentifier) {
        // TLDR: Angular adds `popstate` event listener and then doesn't remove it when application gets destroyed.
        // Basically, Angular has a potentional memory leak. The `ɵBrowserPlatformLocation`
        // has `onPopState` method which adds `popstate` event listener and forgets, see here:
        // https://github.com/angular/angular/blob/14be55c9facf3e47b8c97df4502dc3f0f897da03/packages/common/src/location/platform_location.ts#L126
        const zone = [...this.zoneToOnPopStateListenersMap.keys()].find(
        // `getZoneWith` will return a zone which defines a `key` and in our case
        // we define a custom key in `single-spa-angular.ts`
        // via this line of code:
        // `_properties[zoneIdentifier] = true;`
        zone => zone.getZoneWith(zoneIdentifier) !== null);
        const onPopStateListeners = this.zoneToOnPopStateListenersMap.get(zone);
        if (Array.isArray(onPopStateListeners)) {
            for (const onPopStateListener of onPopStateListeners) {
                window.removeEventListener('popstate', onPopStateListener);
            }
        }
        this.zoneToOnPopStateListenersMap.delete(zone);
    }
    pushState(state, title, url) {
        this.skipNextPopState = true;
        super.pushState(state, title, url);
    }
    replaceState(state, title, url) {
        this.skipNextPopState = true;
        super.replaceState(state, title, url);
    }
    onPopState(fn) {
        // `Zone.current` will reference the zone that serves as an execution context
        // to some specific application, especially when `onPopState` is called.
        const zone = Zone.current;
        // Wrap any event listener into zone that is specific to some application.
        // The main issue is `back/forward` buttons of browsers, because they invoke
        // `history.back|forward` which dispatch `popstate` event. Since `single-spa`
        // overrides `history.replaceState` Angular's zone cannot intercept this event.
        // Only the root zone is able to intercept all events.
        // See https://github.com/single-spa/single-spa-angular/issues/94 for more details
        fn = zone.wrap(fn, `${this.source++}`);
        const onPopStateListener = (event) => {
            // The `LocationChangeEvent` doesn't have the `singleSpa` property, since it's added
            // by `single-spa` starting from `5.4` version. We need this check because we want
            // to skip "unnatural" PopStateEvents, the one caused by `single-spa`.
            const popStateEventWasDispatchedBySingleSpa = !!event
                .singleSpa;
            if (this.skipNextPopState && popStateEventWasDispatchedBySingleSpa) {
                this.skipNextPopState = false;
            }
            else {
                fn(event);
            }
        };
        this.storeOnPopStateListener(zone, onPopStateListener);
        super.onPopState(onPopStateListener);
    }
    storeOnPopStateListener(zone, onPopStateListener) {
        // All listeners should be stored inside an array because the `onPopState` can be called
        // multiple times thus we wanna reference all listeners to remove them further.
        const onPopStateListeners = this.zoneToOnPopStateListenersMap.get(zone) || [];
        onPopStateListeners.push(onPopStateListener);
        if (!this.zoneToOnPopStateListenersMap.has(zone)) {
            this.zoneToOnPopStateListenersMap.set(zone, onPopStateListeners);
        }
    }
}
SingleSpaPlatformLocation.ɵfac = function SingleSpaPlatformLocation_Factory(t) { return ɵSingleSpaPlatformLocation_BaseFactory(t || SingleSpaPlatformLocation); };
SingleSpaPlatformLocation.ɵprov = ɵngcc0.ɵɵdefineInjectable({ token: SingleSpaPlatformLocation, factory: SingleSpaPlatformLocation.ɵfac });
const ɵSingleSpaPlatformLocation_BaseFactory = ɵngcc0.ɵɵgetInheritedFactory(SingleSpaPlatformLocation);
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(SingleSpaPlatformLocation, [{
        type: Injectable
    }], null, null); })();
/**
 * The `PlatformLocation` class is an "injectee" of the `PathLocationStrategy`,
 * which creates `Subject` internally for listening on `popstate` events. We want
 * to provide this class in the most top injector that's used during bootstrapping.
 */
function getSingleSpaExtraProviders() {
    return [
        {
            provide: SingleSpaPlatformLocation,
            useClass: SingleSpaPlatformLocation,
            deps: [[new Inject(DOCUMENT)]],
        },
        {
            provide: PlatformLocation,
            useExisting: SingleSpaPlatformLocation,
        },
    ];
}

const defaultOptions = {
    // Required options that will be set by the library consumer.
    NgZone: null,
    bootstrapFunction: null,
    template: null,
    // Optional options
    Router: undefined,
    domElementGetter: undefined,
    AnimationEngine: undefined,
    updateFunction: () => Promise.resolve(),
};
function singleSpaAngular(userOptions) {
    if (typeof userOptions !== 'object') {
        throw Error('single-spa-angular requires a configuration object');
    }
    const options = Object.assign(Object.assign({}, defaultOptions), userOptions);
    if (typeof options.bootstrapFunction !== 'function') {
        throw Error('single-spa-angular must be passed an options.bootstrapFunction');
    }
    if (typeof options.template !== 'string') {
        throw Error('single-spa-angular must be passed options.template string');
    }
    if (!options.NgZone) {
        throw Error(`single-spa-angular must be passed the NgZone option`);
    }
    if (options.Router && !options.NavigationStart) {
        // We call `console.warn` except of throwing `new Error()` since this will not
        // be a breaking change.
        console.warn(`single-spa-angular must be passed the NavigationStart option`);
    }
    return {
        bootstrap: bootstrap.bind(null, options),
        mount: mount.bind(null, options),
        unmount: unmount.bind(null, options),
        update: options.updateFunction,
    };
}
function bootstrap(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        // Angular provides an opportunity to develop `zone-less` application, where developers
        // have to trigger change detection manually.
        // See https://angular.io/guide/zone#noopzone
        if (options.NgZone === 'noop') {
            return;
        }
        // In order for multiple Angular apps to work concurrently on a page, they each need a unique identifier.
        options.zoneIdentifier = `single-spa-angular:${props.name || props.appName}`;
        // This is a hack, since NgZone doesn't allow you to configure the property that identifies your zone.
        // See https://github.com/PlaceMe-SAS/single-spa-angular-cli/issues/33,
        // https://github.com/single-spa/single-spa-angular/issues/47,
        // https://github.com/angular/angular/blob/a14dc2d7a4821a19f20a9547053a5734798f541e/packages/core/src/zone/ng_zone.ts#L144,
        // and https://github.com/angular/angular/blob/a14dc2d7a4821a19f20a9547053a5734798f541e/packages/core/src/zone/ng_zone.ts#L257
        options.NgZone.isInAngularZone = () => {
            // @ts-ignore
            return window.Zone.current._properties[options.zoneIdentifier] === true;
        };
        options.routingEventListener = () => {
            options.bootstrappedNgZone.run(() => {
                // See https://github.com/single-spa/single-spa-angular/issues/86
                // Zone is unaware of the single-spa navigation change and so Angular change detection doesn't work
                // unless we tell Zone that something happened
            });
        };
    });
}
function mount(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        getContainerElementAndSetTemplate(options, props);
        const bootstrapPromise = options.bootstrapFunction(props);
        if (!(bootstrapPromise instanceof Promise)) {
            throw Error(`single-spa-angular: the options.bootstrapFunction must return a promise, but instead returned a '${typeof bootstrapPromise}' that is not a Promise`);
        }
        const module = yield bootstrapPromise;
        if (!module || typeof module.destroy !== 'function') {
            throw Error(`single-spa-angular: the options.bootstrapFunction returned a promise that did not resolve with a valid Angular module. Did you call platformBrowserDynamic().bootstrapModule() correctly?`);
        }
        const singleSpaPlatformLocation = module.injector.get(SingleSpaPlatformLocation, null);
        const ngZoneEnabled = options.NgZone !== 'noop';
        // The user has to provide `BrowserPlatformLocation` only if his application uses routing.
        // So if he provided `Router` but didn't provide `BrowserPlatformLocation` then we have to inform him.
        // Also `getSingleSpaExtraProviders()` function should be called only if the user doesn't use
        // `zone-less` change detection, if `NgZone` is `noop` then we can skip it.
        if (ngZoneEnabled && options.Router && singleSpaPlatformLocation === null) {
            throw new Error(`
      single-spa-angular: could not retrieve extra providers from the platform injector. Did you call platformBrowserDynamic(getSingleSpaExtraProviders()).bootstrapModule()?
    `);
        }
        const bootstrappedOptions = options;
        if (ngZoneEnabled) {
            const ngZone = module.injector.get(options.NgZone);
            const zoneIdentifier = bootstrappedOptions.zoneIdentifier;
            // `NgZone` can be enabled but routing may not be used thus `getSingleSpaExtraProviders()`
            // function was not called.
            if (singleSpaPlatformLocation !== null) {
                skipLocationChangeOnNonImperativeRoutingTriggers(module, options);
                // Cleanup resources, especially remove event listeners thus they will not be added
                // twice when application gets bootstrapped the second time.
                module.onDestroy(() => {
                    singleSpaPlatformLocation.destroyApplication(zoneIdentifier);
                });
            }
            bootstrappedOptions.bootstrappedNgZone = ngZone;
            bootstrappedOptions.bootstrappedNgZone['_inner']._properties[zoneIdentifier] = true;
            window.addEventListener('single-spa:routing-event', bootstrappedOptions.routingEventListener);
        }
        bootstrappedOptions.bootstrappedModule = module;
        return module;
    });
}
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function unmount(options, props) {
    return __awaiter(this, void 0, void 0, function* () {
        if (options.Router) {
            // Workaround for https://github.com/angular/angular/issues/19079
            const router = options.bootstrappedModule.injector.get(options.Router);
            router.dispose();
        }
        if (options.routingEventListener) {
            window.removeEventListener('single-spa:routing-event', options.routingEventListener);
        }
        if (options.AnimationEngine) {
            /*
            The BrowserAnimationsModule does not clean up after itself :'(. When you unmount/destroy the main module, the
            BrowserAnimationsModule uses an AnimationRenderer thing to remove dom elements from the page. But the AnimationRenderer
            defers the actual work to the TransitionAnimationEngine to do this, and the TransitionAnimationEngine doesn't actually
            remove the dom node, but just calls "markElementAsRemoved()".
        
            See https://github.com/angular/angular/blob/db62ccf9eb46ee89366ade586365ea027bb93eb1/packages/animations/browser/src/render/transition_animation_engine.ts#L717
        
            What markAsRemovedDoes is put it into an array called "collectedLeaveElements", which is all the elements that should be removed
            after the DOM has had a chance to do any animations.
        
            See https://github.com/angular/angular/blob/master/packages/animations/browser/src/render/transition_animation_engine.ts#L525
        
            The actual dom nodes aren't removed until the TransitionAnimationEngine "flushes".
        
            See https://github.com/angular/angular/blob/db62ccf9eb46ee89366ade586365ea027bb93eb1/packages/animations/browser/src/render/transition_animation_engine.ts#L851
        
            Unfortunately, though, that "flush" will never happen, since the entire module is being destroyed and there will be no more flushes.
            So what we do in this code is force one more flush of the animations after the module is destroyed.
        
            Ideally, we would do this by getting the TransitionAnimationEngine directly and flushing it. Unfortunately, though, it's private class
            that cannot be imported and is not provided to the dependency injector. So, instead, we get its wrapper class, AnimationEngine, and then
            access its private variable reference to the TransitionAnimationEngine so that we can call flush.
            */
            const animationEngine = options.bootstrappedModule.injector.get(options.AnimationEngine);
            animationEngine._transitionEngine.flush();
        }
        options.bootstrappedModule.destroy();
        delete options.bootstrappedModule;
        // This is an issue. Issue has been created and Angular team is working on the fix:
        // https://github.com/angular/angular/issues/36449
        removeApplicationFromDOMIfIvyEnabled(options, props);
    });
}
function skipLocationChangeOnNonImperativeRoutingTriggers(module, options) {
    if (!options.NavigationStart) {
        // As discussed we don't do anything right now if the developer doesn't provide
        // `options.NavigationStart` since this might be a breaking change.
        return;
    }
    const router = module.injector.get(options.Router);
    const subscription = router.events.subscribe((event) => {
        if (event instanceof options.NavigationStart) {
            const currentNavigation = router.getCurrentNavigation();
            // This listener will be set up for each Angular application
            // that has routing capabilities.
            // We set `skipLocationChange` for each non-imperative navigation,
            // Angular router checks under the hood if it has to change
            // the browser URL or not.
            // If `skipLocationChange` is truthy then Angular router will not call
            // `setBrowserUrl()` which calls `history.replaceState()` and dispatches `popstate` event.
            if (currentNavigation.trigger !== 'imperative') {
                currentNavigation.extras.skipLocationChange = true;
                currentNavigation.extras.replaceUrl = false;
            }
        }
    });
    module.onDestroy(() => {
        subscription.unsubscribe();
    });
}

class ParcelComponent {
    // eslint-disable-next-line @typescript-eslint/no-parameter-properties
    constructor(host) {
        this.host = host;
        this.onParcelMount = null;
        this.wrapWith = 'div';
        this.customProps = {};
        this.appendTo = null;
        this.handleError = (error) => console.error(error);
        this.createdDomElement = null;
        this.hasError = false;
        this.unmounted = true;
    }
    ngOnInit() {
        if (!this.config) {
            throw new Error(`single-spa-angular's Parcel component requires the [config] binding to either be a parcel config or a loading function that returns a promise. See https://github.com/CanopyTax/single-spa-angular`);
        }
        this.addThingToDo('mount', () => {
            const mountParcel = this.mountParcel;
            if (!mountParcel) {
                throw new Error(`
				  <parcel> was not passed a [mountParcel] binding.
				  If you are using <parcel> within a module that is not a single-spa application, you will need to import mountRootParcel from single-spa and pass it into <parcel> as a [mountParcel] binding
				`);
            }
            let domElement;
            if (this.appendTo) {
                this.createdDomElement = domElement = document.createElement(this.wrapWith);
                this.appendTo.appendChild(domElement);
            }
            else {
                this.createdDomElement = domElement = document.createElement(this.wrapWith);
                // Except of having `@ViewChild` we can simply get the first child element.
                const parcelDiv = this.host.nativeElement.children[0];
                parcelDiv.appendChild(domElement);
            }
            this.parcel = mountParcel(this.config, Object.assign({ domElement }, this.customProps));
            if (this.onParcelMount) {
                this.parcel.mountPromise.then(this.onParcelMount);
            }
            this.unmounted = false;
            return this.parcel.mountPromise;
        });
    }
    ngOnChanges() {
        this.addThingToDo('update', () => {
            if (this.parcel && this.parcel.update) {
                return this.parcel.update(this.customProps);
            }
        });
    }
    ngOnDestroy() {
        this.addThingToDo('unmount', () => {
            if (this.parcel && this.parcel.getStatus() === 'MOUNTED') {
                return this.parcel.unmount();
            }
        });
        if (this.createdDomElement) {
            this.createdDomElement.parentNode.removeChild(this.createdDomElement);
        }
        this.unmounted = true;
    }
    addThingToDo(action, thing) {
        if (this.hasError && action !== 'unmount') {
            // In an error state, we don't do anything anymore except for unmounting
            return;
        }
        this.nextThingToDo = (this.nextThingToDo || Promise.resolve())
            .then((...args) => {
            if (this.unmounted && action !== 'unmount') {
                // Never do anything once the angular component unmounts
                return;
            }
            return thing(...args);
        })
            .catch(error => {
            this.nextThingToDo = Promise.resolve(); // reset so we don't .then() the bad promise again
            this.hasError = true;
            if (error && error.message) {
                error.message = `During '${action}', parcel threw an error: ${error.message}`;
            }
            if (typeof this.handleError === 'function') {
                this.handleError(error);
            }
            else {
                setTimeout(() => {
                    throw error;
                });
            }
            // No more things to do should be done -- the parcel is in an error state
            throw error;
        });
    }
}
ParcelComponent.ɵfac = function ParcelComponent_Factory(t) { return new (t || ParcelComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
ParcelComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: ParcelComponent, selectors: [["parcel"]], inputs: { onParcelMount: "onParcelMount", wrapWith: "wrapWith", customProps: "customProps", appendTo: "appendTo", handleError: "handleError", config: "config", mountParcel: "mountParcel" }, features: [ɵngcc0.ɵɵNgOnChangesFeature], decls: 1, vars: 0, template: function ParcelComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelement(0, "div");
    } }, encapsulation: 2 });
ParcelComponent.ctorParameters = () => [
    { type: ElementRef }
];
ParcelComponent.propDecorators = {
    config: [{ type: Input }],
    mountParcel: [{ type: Input }],
    onParcelMount: [{ type: Input }],
    wrapWith: [{ type: Input }],
    customProps: [{ type: Input }],
    appendTo: [{ type: Input }],
    handleError: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ParcelComponent, [{
        type: Component,
        args: [{
                selector: 'parcel',
                template: '<div></div>'
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { onParcelMount: [{
            type: Input
        }], wrapWith: [{
            type: Input
        }], customProps: [{
            type: Input
        }], appendTo: [{
            type: Input
        }], handleError: [{
            type: Input
        }], config: [{
            type: Input
        }], mountParcel: [{
            type: Input
        }] }); })();

class ParcelModule {
}
ParcelModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: ParcelModule });
ParcelModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function ParcelModule_Factory(t) { return new (t || ParcelModule)(); } });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(ParcelModule, { declarations: [ParcelComponent], exports: [ParcelComponent] }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ParcelModule, [{
        type: NgModule,
        args: [{
                declarations: [ParcelComponent],
                exports: [ParcelComponent],
                entryComponents: [ParcelComponent]
            }]
    }], null, null); })();

/**
 * The public api for consumers of single-spa-angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ParcelComponent, ParcelModule, getSingleSpaExtraProviders, singleSpaAngular, SingleSpaPlatformLocation as ɵa };

//# sourceMappingURL=single-spa-angular.js.map