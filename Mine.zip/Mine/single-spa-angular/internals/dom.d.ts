import { BaseSingleSpaAngularOptions } from './types';
export declare function removeApplicationFromDOMIfIvyEnabled<T extends BaseSingleSpaAngularOptions>(options: T, props: any): void;
export declare function getContainerElementAndSetTemplate<T extends BaseSingleSpaAngularOptions>(options: T, props: any): HTMLElement;
