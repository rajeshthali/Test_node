export * from './types';
export { getContainerElementAndSetTemplate, removeApplicationFromDOMIfIvyEnabled } from './dom';
