import { BrowserBuilderOptions } from '@angular-devkit/build-angular';
export interface DefaultExtraOptions {
    removeMiniCssExtract: boolean;
}
interface Options extends Partial<BrowserBuilderOptions> {
    customWebpackConfig?: {
        libraryName?: string;
        libraryTarget?: string;
    };
}
declare const _default: (config: any, options?: Options | undefined, extraOptions?: DefaultExtraOptions | undefined) => any;
export default _default;
