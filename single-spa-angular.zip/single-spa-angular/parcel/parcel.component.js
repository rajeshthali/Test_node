"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
let ParcelComponent = class ParcelComponent {
    constructor() {
        this.wrapWith = 'div';
        this.handleError = err => console.error(err);
    }
    ngOnInit() {
        if (!this.config) {
            throw new Error(`single-spa-angular's Parcel component requires the 'config' prop to either be a parcel config or a loading function that returns a promise. See https://github.com/CanopyTax/single-spa-angular`);
        }
        this.addThingToDo('mount', () => {
            const mountParcel = this.mountParcel;
            if (!mountParcel) {
                throw new Error(`
				  <parcel> was not passed a mountParcel prop.
				  If you are using <parcel> within a module that is not a single-spa application, you will need to import mountRootParcel from single-spa and pass it into <parcel> as a mountParcel prop
				`);
            }
            let domElement;
            if (this.appendTo) {
                this.createdDomElement = domElement = document.createElement(this.wrapWith);
                this.appendTo.appendChild(domElement);
            }
            else {
                this.createdDomElement = domElement = document.createElement(this.wrapWith);
                this.parcelDiv.nativeElement.appendChild(domElement);
            }
            this.parcel = mountParcel(this.config, Object.assign({ domElement }, this.customProps));
            if (this.onParcelMount) {
                this.parcel.mountPromise.then(this.onParcelMount);
            }
            this.unmounted = false;
            return this.parcel.mountPromise;
        });
    }
    ngOnChanges() {
        this.addThingToDo('update', () => {
            if (this.parcel && this.parcel.update) {
                return this.parcel.update(this.customProps);
            }
        });
    }
    ngOnDestroy() {
        this.addThingToDo('unmount', () => {
            if (this.parcel && this.parcel.getStatus() === "MOUNTED") {
                return this.parcel.unmount();
            }
        });
        if (this.createdDomElement) {
            this.createdDomElement.parentNode.removeChild(this.createdDomElement);
        }
        this.unmounted = true;
    }
    addThingToDo(action, thing) {
        if (this.hasError && action !== 'unmount') {
            // In an error state, we don't do anything anymore except for unmounting
            return;
        }
        this.nextThingToDo = (this.nextThingToDo || Promise.resolve())
            .then((...args) => {
            if (this.unmounted && action !== 'unmount') {
                // Never do anything once the angular component unmounts
                return;
            }
            return thing(...args);
        })
            .catch(err => {
            this.nextThingToDo = Promise.resolve(); // reset so we don't .then() the bad promise again
            this.hasError = true;
            if (err && err.message) {
                err.message = `During '${action}', parcel threw an error: ${err.message}`;
            }
            if (this.handleError) {
                this.handleError(err);
            }
            else {
                setTimeout(() => { throw err; });
            }
            // No more things to do should be done -- the parcel is in an error state
            throw err;
        });
    }
};
__decorate([
    core_1.ViewChild('parcelDiv'),
    __metadata("design:type", core_1.ElementRef)
], ParcelComponent.prototype, "parcelDiv", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ParcelComponent.prototype, "config", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ParcelComponent.prototype, "mountParcel", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Function)
], ParcelComponent.prototype, "onParcelMount", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ParcelComponent.prototype, "wrapWith", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ParcelComponent.prototype, "customProps", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ParcelComponent.prototype, "appendTo", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ParcelComponent.prototype, "handleError", void 0);
ParcelComponent = __decorate([
    core_1.Component({
        selector: 'parcel',
        template: `
  <div #parcelDiv></div>
  `
    }),
    __metadata("design:paramtypes", [])
], ParcelComponent);
exports.ParcelComponent = ParcelComponent;
//# sourceMappingURL=parcel.component.js.map