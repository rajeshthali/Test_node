export declare class ParcelModule {
}
