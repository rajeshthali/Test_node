import { OnInit, OnDestroy, OnChanges, ElementRef } from '@angular/core';
import { Parcel, ParcelConfig } from 'single-spa';
export declare class ParcelComponent implements OnInit, OnDestroy, OnChanges {
    parcelDiv: ElementRef;
    config: ParcelConfig;
    mountParcel: any;
    onParcelMount: () => void;
    wrapWith: string;
    customProps: any;
    appendTo: any;
    handleError: (err: any) => void;
    createdDomElement: any;
    hasError: boolean;
    unmounted: any;
    nextThingToDo: Promise<any>;
    parcel: Parcel;
    constructor();
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    addThingToDo(action: any, thing: any): void;
}
