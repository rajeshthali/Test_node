export declare const singleSpaAngular = "^3.0.0";
export declare const angularBuilderCustomWebpack = "^8";
