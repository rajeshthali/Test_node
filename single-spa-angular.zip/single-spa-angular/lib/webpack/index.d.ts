declare const _default: (config: any, options: any) => any;
export default _default;
