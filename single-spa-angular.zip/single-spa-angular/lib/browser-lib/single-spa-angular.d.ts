import { AppProps, LifeCycles } from 'single-spa';
export default function singleSpaAngular(userOpts: SingleSpaAngularOpts): LifeCycles;
interface SingleSpaAngularOpts {
    NgZone: any;
    bootstrapFunction(props: AppProps): Promise<any>;
    updateFunction?(props: AppProps): Promise<any>;
    template: string;
    Router?: any;
    domElementGetter?(): HTMLElement;
    AnimationEngine?: any;
}
export { getSingleSpaExtraProviders } from './extra-providers';
