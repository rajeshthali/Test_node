import { NgZone, StaticProvider } from '@angular/core';
import { LocationChangeEvent } from '@angular/common';
import { ɵBrowserPlatformLocation } from '@angular/platform-browser';
export declare class SingleSpaPlatformLocation extends ɵBrowserPlatformLocation {
    private ngZone;
    private skipNextPopState;
    private onPopStateListeners;
    destroy(): void;
    pushState(state: any, title: string, url: string): void;
    replaceState(state: any, title: string, url: string): void;
    onPopState(fn: (event: LocationChangeEvent) => void): void;
    setNgZone(ngZone: NgZone): void;
}
/**
 * The `PlatformLocation` class is an "injectee" of the `PathLocationStrategy`,
 * which creates `Subject` internally for listening on `popstate` events. We want
 * to provide this class in the most top injector that's used during bootstrapping.
 */
export declare function getSingleSpaExtraProviders(): StaticProvider[];
